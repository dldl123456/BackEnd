package com.crawl.zhihu;

public class ModelLoginTest {
    public static void main(String[] args){
        new ModelLogin().login("", "");
    }

}
