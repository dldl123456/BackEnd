package com.crawl.core.parser;

public interface Parser {

}
