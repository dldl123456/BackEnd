/**
 *  创建一个JavaBean对象------JavaBean对象本质是一个类
	JavaBean  遵循一定的设计原则的任何JAVA类都可以是Javabean组件. Javabean的本质就是一个类.
	1)可序列化
	2)无参数的构造方法 
	3)类的私有属性   private 
	4)通过公有的方法获取和设置属性   getter/setter 方法
*/

package javabean;

public class User implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String username;
	private String password;
	
	public User() {}

	//面向对象的封装
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		System.out.println("username：" + username);
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + "]";
	}
}