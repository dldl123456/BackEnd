package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javabean.User;

public class MapServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user1 = new User("fsd", "484cvsd");
		User user2 = new User("hngf", "484cvsd");
		User user3 = new User("asd", "12443245");
		User user4 = new User("kyu", "345245");
		User user5 = new User("das", "245");
		
		//map集合如何传值到页面，如何取值(无序不重复)
		Map<String, User> userMap = new HashMap<>();
		userMap.put("1", user1);
		userMap.put("2", user2);
		userMap.put("3", user3);
		userMap.put("4", user4);
		userMap.put("5", user5);
		
		request.setAttribute("userMap", userMap);
		
		//在页面取map集合
		request.getRequestDispatcher("jstl3.jsp").forward(request, response);
	}

}
