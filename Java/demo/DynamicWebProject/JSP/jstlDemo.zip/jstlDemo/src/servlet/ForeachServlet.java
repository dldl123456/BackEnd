package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javabean.User;

public class ForeachServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//从数据库中获取数据(放入集合)
		List<User> users = new ArrayList<>();
		
		User user1 = new User("fsd", "484cvsd");
		User user2 = new User("hngf", "484cvsd");
		User user3 = new User("asd", "12443245");
		User user4 = new User("kyu", "345245");
		User user5 = new User("das", "245");
		
		users.add(user1);
		users.add(user2);
		users.add(user3);
		users.add(user4);
		users.add(user5);
		
		//传数据(一般用request传值)（千万不能用session和application[数据永远存在除非服务器停止]，生命周期太长）
		request.setAttribute("users", users);    //把数据存在request对象
		//服务端跳转传值(客户端跳转不能共享数据(重定向))
		//（共享request对象数据）
		request.getRequestDispatcher("jstl3.jsp").forward(request, response);
	}

}
