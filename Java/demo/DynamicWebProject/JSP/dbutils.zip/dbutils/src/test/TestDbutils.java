/**
 * 增删改查，测试dbutil
 */

package test;

import org.junit.Test;

import dao.UserDao;
import dao.impl.UserDaoImpl;
import db.DButil;
import po.User;

public class TestDbutils {
	
	//实例化
	User user = new User(8, "vfd", "lhiugjjbn");
	
	UserDao udi = new UserDaoImpl();
	
	//测试数据库
	@Test
	public void testGetConnection(){
		//DButil
		DButil db = new DButil();
		System.out.println("测试数据库是否连接成功：" + db.getConnection() + "\n");
	}
	
	//测试User实体类
	@Test
	public void testUser(){
		System.out.println("测试实体类是否输出正常：" + user.toString() + "\n");
	}
	
	//测试添加用户
	@Test
	public void addUser(){
		//UserDao
		System.out.println("测试数据添加是否正常：" + udi.addUser() + "\n");
	}
}
