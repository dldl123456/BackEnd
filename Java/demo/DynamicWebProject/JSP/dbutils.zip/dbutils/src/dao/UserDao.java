package dao;

public interface UserDao {
	//添加用户
	public int addUser();
}
