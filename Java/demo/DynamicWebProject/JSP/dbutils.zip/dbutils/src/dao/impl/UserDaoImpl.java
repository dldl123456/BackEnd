package dao.impl;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import dao.UserDao;
import db.DButil;

public class UserDaoImpl implements UserDao {
	
	//核心类（运行sql语句）
	//对象封装对JDBC操作的核心对象
	private QueryRunner qr = new QueryRunner();
	
	private DButil db;  //数据库工具类
	private Connection conn;  //连接数据库对象
	
	//构造方法初始化
	public UserDaoImpl(){
		db = new DButil();
	}

	//添加用户
	@Override
	public int addUser() {
		conn = db.getConnection();
		String sql = "insert into user (username, password) values(?, ?)";
		
		try {
			//影响的行数(连接，sql，参数)
			Object[] params = new Object[]{"ddd", "cds"};
			int count = qr.update(conn, sql, params);
			
			return count;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}

}
