package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.UserService;
import service.impl.UserServiceImpl;

public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserService userService = new UserServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//拿到页面传过来的id的值,并转成整型
		int id = Integer.parseInt(request.getParameter("id"));
		
		boolean success = userService.deleteUserById(id);
		
		if (success) {
			response.sendRedirect("query.do");
		} else {
			response.sendRedirect("index.jsp");
		}
	}

}
