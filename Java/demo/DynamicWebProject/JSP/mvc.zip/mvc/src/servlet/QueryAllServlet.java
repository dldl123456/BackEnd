package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import po.User;
import service.UserService;
import service.impl.UserServiceImpl;

public class QueryAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserService userService = new UserServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<User> userList = userService.queryAllUser();
		
		//把集合放到request内置对象里面
		request.setAttribute("users", userList);
		
		//跳转到页面(服务端跳转，内部跳转)
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}
}
