package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.UserService;
import service.impl.UserServiceImpl;

public class LoginServlert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserService userService = new UserServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		HttpSession session = request.getSession();
		
		boolean success = userService.login(username, password);
		
		if (success) {
			//如果数据登陆成功，存入session
			session.setAttribute("username", username);
			session.setAttribute("password", password);
			
			//跳转(客户端跳转)
			response.sendRedirect("query.do");  //跳转到servlet里面
		} else {
			//如果不成功，停留在当前页面
			response.sendRedirect("login.jsp");
		}
	}
}
