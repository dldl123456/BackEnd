package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import po.User;
import service.UserService;
import service.impl.UserServiceImpl;

public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserService userService = new UserServiceImpl();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//拿到页面传过来的id的值,并转成整型
		int id = Integer.parseInt(request.getParameter("id"));
		
		//查出当前点击的一条记录
		User user = userService.getUserById(id);
		
		//赋值
		request.setAttribute("user", user);
		request.getRequestDispatcher("update.jsp").forward(request, response);
	}
}
