package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import po.PageBean;
import po.User;
import service.UserService;
import service.impl.UserServiceImpl;

public class QueryUserPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserService userService = new UserServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//页的大小（每页的大小，，3条记录）
		int ps = 3;
		//页码
		int pc = getPc(request, response);
		
		PageBean<User> pageBean = userService.queryUserByPage(pc, ps);
		
		//保存数据
		request.setAttribute("pb", pageBean);
		
		//传值到页面（服务端跳转）
		request.getRequestDispatcher("userlist.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	//获取当前页
	protected int getPc(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pc = request.getParameter("pc");
		
		//如果当前页码为空，并且去掉空格也为空
		//为空返回1，不为空，把字符串转整型返回，页码
		if(pc == null || pc.trim().isEmpty()){
			return 1;
		}
		
		return Integer.parseInt(pc);
	}
}
