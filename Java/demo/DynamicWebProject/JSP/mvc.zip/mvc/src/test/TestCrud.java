/**
 * 增删改查，测试mvc
 */

package test;

import java.util.List;

import org.junit.Test;

import dao.UserDao;
import dao.impl.UserDaoImpl;
import db.DButil;
import po.User;
import service.UserService;
import service.impl.UserServiceImpl;

public class TestCrud {
	
	//实例化
	User user = new User(8, "vfd", "lhiugjjbn");
	
	private static UserDao udi = new UserDaoImpl();
	private static UserService usi = new UserServiceImpl();
	
	//测试数据库
	@Test
	public void testGetConnection(){
		//DButil
		DButil db = new DButil();
		System.out.println("测试数据库是否连接成功：" + db.getConnection() + "\n");
	}
	
	//测试User实体类
	//@Test
	public void testUser(){
		System.out.println("测试实体类是否输出正常：" + user.toString() + "\n");
	}
	
	//测试查询所有用户
	//@Test
	public void testQueryUser(){
		//UserDao
		System.out.println("测试数据是否查询成功（查询所有用户）：");
		List<User> userListD = udi.queryAllUser();
		for(User us : userListD){
			System.out.println(us);
		}
		System.out.println();
		
		//UserService
		System.out.println("测试业务数据是否查询成功（查询所有用户）：");
		List<User> userListS = usi.queryAllUser();
		for(User us : userListS){
			System.out.println(us);
		}
		System.out.println();
	}
	
	//测试添加用户
	//@Test
	public void testAddUser(){
		//UserDao
		System.out.println("测试数据是否添加成功：" + udi.addUser(user) + "\n");
		
		//UserService
		System.out.println("测试业务数据是否添加成功："  + usi.addUser(user) + "\n");
	}
	
	//测试删除用户
	//@Test
	public void testDeleteUserById(){
		//UserDao
		System.out.println("测试数据是否删除成功：" + udi.deleteUserById(1) + "\n");
		
		//UserService
		System.out.println("测试业务数据是否删除成功：" + usi.deleteUserById(1) + "\n");
	}
	
	//测试修改用户
	//@Test
	public void testUpdatateUser(){
		User user = new User(3, "vf333d", "1231hbfgdd23");
		
		//UserDao
		System.out.println("测试数据是否修改成功：" + udi.updatateUser(user) + "\n");
		
		//UserService
		System.out.println("测试业务数据是否修改成功：" + usi.updatateUser(user) + "\n");
	}
	
	//测试查一条记录
	//@Test
	public void testGetUserById(){
		//UserDao
		System.out.println("测试数据是否查询成功（查一条记录）：\n\t" + udi.getUserById(2) + "\n");
		
		//UserService
		System.out.println("测试业务数据是否查询成功（查一条记录）：" + usi.getUserById(2) + "\n");
	}
	
	//测试登陆
	//@Test
	public void testLogin(){
		//UserDao
		System.out.println("测试数据是否查询成功（登陆）：" + udi.login("zs", "123123") + "\n");
		
		//UserService
		System.out.println("测试业务数据是否查询成功（登陆）：" + usi.login("zs", "123123") + "\n");
	}
	
	//测试总记录数
	//@Test
	public void testCountUser(){
		//UserDao
		System.out.println("测试数据是否查询成功（登陆）：" + udi.countUser() + "\n");
		
		//UserService
		System.out.println("测试业务数据是否查询成功（登陆）：" + usi.countUser() + "\n");
	}
	
	//测试分页查询
	@Test
	public void testQueryUserByPage(){
		//UserDao
		System.out.println("测试数据是否查询成功（分页）：" + udi.queryUserByPage(1, 2) + "\n");
		
		//UserService
		//System.out.println("测试业务数据是否查询成功（分页）：" + usi.queryUserByPage(1, 2) + "\n");
	}
}
