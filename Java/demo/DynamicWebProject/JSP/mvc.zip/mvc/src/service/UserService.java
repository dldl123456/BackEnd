package service;

import java.util.List;

import po.User;

public interface UserService {
	//查询所有用户
	public List<User> queryAllUser();
	
	//添加用户
	public boolean addUser(User user);
	
	//删除用户
	public boolean deleteUserById(int id);
	
	//修改用户
	public boolean updatateUser(User user);
	
	//查一条记录
	public User getUserById(int id);
	
	//登陆
	public boolean login(String username, String password);
}
