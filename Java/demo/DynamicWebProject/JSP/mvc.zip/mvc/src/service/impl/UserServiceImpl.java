package service.impl;

import java.util.List;

import dao.UserDao;
import dao.impl.UserDaoImpl;
import po.User;
import service.UserService;

public class UserServiceImpl implements UserService {
	private UserDao userDao = new UserDaoImpl();
	private int code = 0;  //sql执行状态
	
	//查询所有用户
	@Override
	public List<User> queryAllUser() {
		return userDao.queryAllUser();
	}
	
	//添加用户
	@Override
	public boolean addUser(User user) {
		code = userDao.addUser(user);
		return code == 0 ? false : true;
	}
	
	//删除用户
	@Override
	public boolean deleteUserById(int id) {
		code = userDao.deleteUserById(id);
		return code == 0 ? false : true;
	}
	
	//修改用户
	@Override
	public boolean updatateUser(User user) {
		code = userDao.updatateUser(user);
		return code == 0 ? false : true;
	}
	
	//查一条记录
	@Override
	public User getUserById(int id) {
		return userDao.getUserById(id);
	}

	//登陆
	@Override
	public boolean login(String username, String password) {
		return userDao.login(username, password);
	}
}
