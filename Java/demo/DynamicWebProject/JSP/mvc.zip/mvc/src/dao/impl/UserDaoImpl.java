package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.UserDao;
import db.DButil;
import po.PageBean;
import po.User;

public class UserDaoImpl implements UserDao {
	private DButil db;  //数据库方法
	private Connection conn;  //连接
	private PreparedStatement pstmt;  //预编译
	private ResultSet rs;  //结果集
	
	//构造方法初始化
	public UserDaoImpl(){
		db = new DButil();
	}
	
	//实现查询所有用户
	@Override
	public List<User> queryAllUser() {
		conn = db.getConnection();
		String sql = "select id, username, password from user";
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			User user=null;
			List<User> users=new ArrayList<>();
			
			while(rs.next()){
				user=new User();
				user.setId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				users.add(user);
			}
			
			return users;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closeAll(conn, pstmt, rs);
		}
		
		return null;
	}
	
	//实现添加用户
	@Override
	public int addUser(User user) {
		conn = db.getConnection();  //连接数据库
		String sql = "insert into user (username, password) values(?, ?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            
            return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closeAll(conn, pstmt, rs);
		}
		
		return 0;
	}

	//实现删除用户
	@Override
	public int deleteUserById(int id) {
		conn = db.getConnection();
		String sql = "delete from user where id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, id);
			
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closeAll(conn, pstmt, rs);
		}
		
		return 0;
	}

	//实现修改用户
	@Override
	public int updatateUser(User user) {
		conn = db.getConnection();
		String sql = "update user set username=?, password=? where id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setInt(3, user.getId());
            
            return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closeAll(conn, pstmt, rs);
		}
		
		return 0;
	}

	//实现查一条记录
	@Override
	public User getUserById(int id) {
		conn = db.getConnection();
		String sql = "select id, username, password from user where id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, id);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				int user_id = rs.getInt("id");
				String user_name = rs.getString("username");
				String password = rs.getString("password");
				
				User user = new User(user_id, user_name, password);
				
				return user;
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			db.closeAll(conn, pstmt, rs);
		}
		
		return null;
	}

	//登陆
	@Override
	public boolean login(String username, String password) {
		conn = db.getConnection();
		String sql = "select 1 from user where username=? and password=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			
			rs = pstmt.executeQuery();  //结果集
			
			while(rs.next()){
				return true;
			}	
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closeAll(conn, pstmt, rs);
		}
		
		return false;
	}

	//统计总记录数
	@Override
	public int countUser() {
		conn = db.getConnection();
		String sql = "select count(1) cnt from user";
		
		int cnt = 0;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();  //结果集
			
			while(rs.next()){
				cnt = rs.getInt("cnt");  //根据列名(可以用)
			}
			
			return cnt;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closeAll(conn, pstmt, rs);
		}
		
		return 0;
	}

	//分页查询（查询一页的数据）(当前页，页的大小)
	@Override
	public PageBean<User> queryUserByPage(int pc, int ps) {
		conn = db.getConnection();
		
		PageBean<User> pb = new PageBean<>();  //创建一个分页组件
		pb.setPc(pc);
		pb.setPs(ps);
		int tr = countUser();
		pb.setTr(tr);
		
		String sql = "select * from user limit " + (pc-1)*ps + "," + ps;
		System.out.println(sql);
		
		List<User> users = new ArrayList<>();
		User user = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();  //结果集
			
			while(rs.next()){
				user = new User();
				user.setId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				
				users.add(user);
			}
			
			System.out.println(users);
			
			pb.setBeanList(users);
			
			return pb;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static void main(String[] args) {
		UserDaoImpl udi = new UserDaoImpl();
		System.out.println(udi.queryUserByPage(1, 2));
	}
}
