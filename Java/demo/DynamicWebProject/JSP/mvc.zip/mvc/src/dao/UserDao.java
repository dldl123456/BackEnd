/**
 * 数据访问层(和数据库打交道)
 * Dao data access Object
 * 对数据库做CRUD(增删改查)操作
 */

package dao;

import java.util.List;

import po.PageBean;
import po.User;

public interface UserDao {
	//查询所有用户
	public List<User> queryAllUser();
	
	//添加用户
	public int addUser(User user);
	
	//删除用户
	public int deleteUserById(int id);
	
	//修改用户
	public int updatateUser(User user);
	
	//查一条记录
	public User getUserById(int id);
	
	//登陆
	public boolean login(String username, String password);
	
	//统计总记录数
	public int countUser();
	
	//分页查询（查询一页的数据）(当前页，页的大小)
	public PageBean<User> queryUserByPage(int pc, int ps);
}
