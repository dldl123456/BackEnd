/**
 * 分页组件
 * 泛型：模板，任意类型
 */

package po;

import java.util.List;

public class PageBean<T> {
	private Integer pc;  //当前页码
	private Integer tr;  //总记录数
	private Integer ps;  //页的大小
	private Integer tp;  //总页数
	private List<T> beanList;  //使用者
	
	public Integer getPc() {
		return pc;
	}
	
	public void setPc(Integer pc) {
		this.pc = pc;
	}
	
	public Integer getTr() {
		return tr;
	}
	
	public void setTr(Integer tr) {
		this.tr = tr;
	}
	
	public Integer getPs() {
		return ps;
	}
	
	public void setPs(Integer ps) {
		this.ps = ps;
	}
	
	//100条记录 页的大小10， 共10页  100/10 ==> 10
	//102条记录   102%10  10……2  ==> 1
	public Integer getTp() {
		int tp = tr / ps;
		return tp % ps == 0 ? tp : tp + 1;
	}
	
	//总页数是设值出来的
	/*public void setTp(Integer tp) {
		this.tp = tp;
	}*/
	
	public List<T> getBeanList() {
		return beanList;
	}
	
	public void setBeanList(List<T> beanList) {
		this.beanList = beanList;
	}

	@Override
	public String toString() {
		return "PageBean [pc=" + pc + ", tr=" + tr + ", ps=" + ps + ", tp=" + tp + ", beanList=" + beanList + "]";
	}
}
