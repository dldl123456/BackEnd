# pc-1*ps(当前页-1*页的大小)，ps
select * from user LIMIT 0, 10;

select * from user limit 0,2