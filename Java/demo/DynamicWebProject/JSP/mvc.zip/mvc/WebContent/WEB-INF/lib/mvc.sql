-- 如果存在，删除
DROP DATABASE IF EXISTS `mvc`;

-- 创建数据库
CREATE DATABASE `mvc`;

-- 使用数据库
USE `mvc`;

-- 用户表(user)
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`(
	`id` int(4) NOT NULL PRIMARY KEY auto_increment,  #用户id
	`username` varchar(32) DEFAULT NULL,  #用户名
	`password` varchar(16) DEFAULT NULL  #用户密码
)ENGINE=INNODB CHARSET=utf8;
DESC `user`;

INSERT INTO `user` 
	(`username`, `password`) 
VALUES
	('zs', '123123'),
	('ls', '456456'),
	('ww', '789789');
SELECT * FROM `user`;