-- 如果存在，删除
DROP DATABASE IF EXISTS `servlet`;

-- 创建数据库
CREATE DATABASE `servlet`;

-- 使用数据库
USE `servlet`;

-- 用户表(servlet)
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`(
	`id` int(4) NOT NULL PRIMARY KEY auto_increment,
	`username` varchar(32) DEFAULT NULL,
	`psw` varchar(16) DEFAULT NULL,
	`sex` varchar(16) DEFAULT NULL,
	`loves` varchar(32) DEFAULT NULL
)ENGINE=INNODB CHARSET=utf8;
DESC `tb_user`;

INSERT INTO `tb_user` 
	(`username`, `psw`, `sex`, `loves`) 
VALUES
	('张三', '123123', '男', '音乐'),
	('李四', 'fdssdfda', '男', '网络'),
	('王五', 'fwdesgbf', '女', '运动');
SELECT * FROM `tb_user`;