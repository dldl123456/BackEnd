package service;

import entity.User;

public interface UserService {
	//用户注册
	public boolean register(User user);
}
