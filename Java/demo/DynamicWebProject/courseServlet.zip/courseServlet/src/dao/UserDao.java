package dao;

import entity.User;

public interface UserDao {
	//添加用户
	public int addUser(User user);
}
