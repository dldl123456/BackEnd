package dao;

import po.Department;

public interface DepartmentDao {
	//根据id查部门
	public Department geDeptById(int id);
}
