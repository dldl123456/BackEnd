/*
 * 控制器
 */

package controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import po.Item;

public class ItemController implements Controller {

	/*
	 * req ==> 获取客户端的请求信息
	 * resp ==> 响应客户端的请求
	 */
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<Item> items = new ArrayList<>();
		
		Item item1 = new Item("1001", "aaa", 666);
		Item item2 = new Item("1001", "bbb", 333);
		Item item3 = new Item("1001", "ccc", 222);
		
		items.add(item1);
		items.add(item2);
		items.add(item3);
		
		//需要把数据打包到一个容器中传到页面
		//把集合放到数据模型中
		ModelAndView mv = new ModelAndView();
		//把数据装到容器中（填充数据）
		mv.addObject("items", items);
		//填充视图(页面)
		mv.setViewName("/item");
		
		return mv;
	}

}
