package bean;

public class Hello {

	public Hello() {
		System.out.println("constructor");
	}
	
	public void sayHello(){
		System.out.println("say hello");
	}
}
