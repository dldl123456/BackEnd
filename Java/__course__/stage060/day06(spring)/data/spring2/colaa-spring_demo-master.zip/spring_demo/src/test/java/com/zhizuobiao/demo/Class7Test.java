package com.zhizuobiao.demo;


import com.zhizuobiao.class7.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring.xml")
public class Class7Test {

    @Autowired
    private LoginService loginService;

    @Test
    public void test1() {
        // 使用代理工厂
        ProxyFactory factory = new ProxyFactory();
        // 设置代理目标
        factory.setTarget(loginService);
        // 获取代理对象
        LoginService loginProxy = (LoginService) factory.getProxy();
        // 创建通知（增强代码）
        LoginBeforeAdvice beforeAdvice = new LoginBeforeAdvice();

        LoginAfterAdvice afterAdvice = new LoginAfterAdvice();

        LoginMethodAdvice methodAdvice = new LoginMethodAdvice();

        LoginThrowAdvice throwAdvice = new LoginThrowAdvice();

        // 织入通知
        factory.addAdvice(beforeAdvice);
        factory.addAdvice(afterAdvice);
        factory.addAdvice(throwAdvice);
//        factory.addAdvice(methodAdvice);

        // 调用代理类的方法
//        loginProxy.login();
        loginProxy.check();
    }
}
