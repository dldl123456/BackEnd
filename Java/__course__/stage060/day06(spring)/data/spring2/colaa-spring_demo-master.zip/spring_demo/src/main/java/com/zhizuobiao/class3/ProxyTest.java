package com.zhizuobiao.class3;

/**
 * Created by Administrator on 2017/8/4 0004.
 */
public class ProxyTest {

    public static void main(String[] args) {

        // 正常调用方法
        PersonDao dao = new PersonDaoImpl();
        dao.delete();

        System.out.println("=============");
        System.out.println("=============");
        System.out.println("=============");

        // 通过代理方式调用
        // 1.创建jdk代理实现
        JdkProxy jdkProxy = new JdkProxy(dao);
        // 2.通过jdk代理，返回代理对象
        PersonDao proxyDao = jdkProxy.getProxy();
        // 3. 通过代理对象调用方法
        proxyDao.delete();
    }
}
