package com.zhizuobiao.class10;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

/**
 * 数据访问层
 * 对数据库的操作
 */
@Repository
public class AccountDaoImpl implements AccountDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void inMoney(String inName, double money) {
        String sql = "update account set money = money + ? where name = ?";
        int code = jdbcTemplate.update(sql, money, inName);
    }

    @Override
    public void outMoney(String outName, double money) {
        String sql = "update account set money = money - ? where name = ?";
        int code = jdbcTemplate.update(sql, money, outName);
    }
}
