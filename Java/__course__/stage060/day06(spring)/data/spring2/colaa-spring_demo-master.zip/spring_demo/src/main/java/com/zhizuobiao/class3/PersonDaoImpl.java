package com.zhizuobiao.class3;

/**
 *  如何使用jdk的动态代理，生成PersonDaoImpl类的代理对象？
 */
public class PersonDaoImpl implements PersonDao {
    public int insert() {
//        System.out.println("DBUtil.openCollection()");
        System.out.println("插入");
//        System.out.println("DBUtil.close(Collection conn)");
        return 0;
    }

    public int delete() {
//        System.out.println("DBUtil.openCollection()");
        System.out.println("删除");
//        System.out.println("DBUtil.close(Collection conn)");
        return 0;
    }

    public int update() {
//        System.out.println("DBUtil.openCollection()");
        System.out.println("更新");
//        System.out.println("DBUtil.close(Collection conn)");
        return 0;
    }
}
