package com.zhizuobiao.class7;

import org.springframework.aop.ThrowsAdvice;

/**
 * 异常通知
 */
public class LoginThrowAdvice implements ThrowsAdvice {
    public void afterThrowing(Exception e) {
        System.out.println("Exception");
    }
}
