package com.zhizuobiao.class6;


import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
public class DogDao {

    public int insert() {
        System.out.println("DogDao insert");
        String name = null;
        name.toString();

        return 1111;
    }
}
