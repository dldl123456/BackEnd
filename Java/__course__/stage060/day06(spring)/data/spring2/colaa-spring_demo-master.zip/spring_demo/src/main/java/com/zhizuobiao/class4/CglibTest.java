package com.zhizuobiao.class4;

/**
 * Created by Administrator on 2017/8/4 0004.
 */
public class CglibTest {

    public static void main(String[] args) {

        AdminDao dao = new AdminDao();
        // 传入被代理对象，
        CglibProxy cglibProxy = new CglibProxy(dao);
        // 生成代理对象
        AdminDao proxyDao = cglibProxy.getProxy();

        proxyDao.insert();

    }

}
