package com.zhizuobiao.demo;

import com.zhizuobiao.class1.User;
import com.zhizuobiao.class1.UserServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by Administrator on 2017/8/2 0002.
 */
public class Class1Test {
    private ApplicationContext cxt;

    @Before
    public void init() {
        // 实例化spring容器
        cxt = new ClassPathXmlApplicationContext("beans.xml");
    }

    @Test
    public void test2() {
        // 从spring容器容器中，获取user对象

        // 从容器中获取标签id为user的bean
        User user1 = (User) cxt.getBean("user");
        User user11 = (User) cxt.getBean("user");
        User user111 = (User) cxt.getBean("user");
        User user2 = (User) cxt.getBean("user2");

        System.out.println(user1);
        System.out.println(user111);
        System.out.println(user11);
        System.out.println(user2);
    }

    @Test
    public void test3() {
        UserServiceImpl userService = (UserServiceImpl) cxt.getBean("userService");
        userService.printName();
        // 关闭上下文
        ((AbstractApplicationContext) cxt).close();
    }

    @Test
    public void test4() {
        // 带构造方法的bean
        User user3 = (User) cxt.getBean("user3");
        System.out.println(user3.getName());
        // 关闭上下文
        ((AbstractApplicationContext) cxt).close();
    }

    @Test
    public void test5() {
        UserServiceImpl userService = (UserServiceImpl) cxt.getBean("userService2");
        userService.printUser();
        // 关闭上下文
        ((AbstractApplicationContext) cxt).close();
    }

    @Test
    public void test6() {
        User user = (User) cxt.getBean("user4");

        System.out.println(user);

        cxt.getBean("userService");
        // 关闭上下文
        ((AbstractApplicationContext) cxt).close();
    }
}
