package com.zhizuobiao.test1;

import java.lang.annotation.*;

@Target({ElementType.FIELD}) // 类中成员变量
@Retention(RetentionPolicy.RUNTIME) // 运行时期
@Inherited // 允许子类继承
@Documented // 生成javadoc文档包含注解
public @interface MyAutowired {

    String name() default "";

    String address() default "";

    int age() default 1;
}
