package com.zhizuobiao.class12;

public interface AccountDao {

    /**
     * 存入
     *
     * @param inName 名称
     * @param money  金额
     */
    void inMoney(String inName, double money);


    /**
     * 转出
     *
     * @param outName 名称
     * @param money   金额
     */
    void outMoney(String outName, double money);
}
