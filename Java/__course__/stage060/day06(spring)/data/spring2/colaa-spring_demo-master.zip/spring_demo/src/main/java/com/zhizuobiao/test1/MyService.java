package com.zhizuobiao.test1;

import java.lang.annotation.*;

/**
 * 自定义注解
 */
@Target({ElementType.TYPE}) // 类或接口
@Retention(RetentionPolicy.RUNTIME) // 运行时期
@Inherited // 允许子类继承
@Documented // 生成javadoc文档包含注解
public @interface MyService {

    // 成员变量；必须无参数无异常
    // default 给变量默认值
    String value() default "zhizuobiao";

    //  成员类型有限定：
    //  合法的类型包含：基本类型、String、Class、Annotation、Enumeration

    // 如果注解只有一个成员，成员必须取名为value()，在使用的时候可以或略成员名和赋值符号
    // 没有成员的注解，称作为标记注解
}
