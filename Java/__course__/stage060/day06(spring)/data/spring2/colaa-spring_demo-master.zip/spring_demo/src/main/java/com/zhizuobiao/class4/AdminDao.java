package com.zhizuobiao.class4;

/**
 * Created by Administrator on 2017/8/4 0004.
 */
public class AdminDao {

    public int insert() {
        System.out.println("插入");
        return 1;
    }

    public int update() {
        System.out.println("更新");
        return 1;
    }

}
