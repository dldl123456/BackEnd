package com.zhizuobiao.test1;


import org.springframework.stereotype.Service;

@MyService("hello service")
@Service
public class HelloService {

    @MyAutowired(age = 1)
    private int age;

    @MyAutowired(name = "liudehua")
    private String name;

    @MyAutowired(address = "beijing")
    private String address;

    @MyAutowired(address = "beijing", name = "test", age = 11)
    private String testFiled;
}
