package com.zhizuobiao.demo;


import com.zhizuobiao.class10.AccountService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring.xml")
public class Class10Test {


    @Autowired
    private AccountService accountService;

//    @Autowired
//    @Qualifier("accountServiceProxy")
    private AccountService accountServiceProxy;

    @Test
    public void testAccountDao() {

        accountService.transAccount("aaa", "bbb", 100);
    }

    @Test
    public void testAccountDao2() {

        accountServiceProxy.transAccount("aaa", "bbb", 100);
    }
}
