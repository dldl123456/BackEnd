package com.zhizuobiao.class3;


public interface PersonDao {

    int insert();

    int delete();

    int update();
}
