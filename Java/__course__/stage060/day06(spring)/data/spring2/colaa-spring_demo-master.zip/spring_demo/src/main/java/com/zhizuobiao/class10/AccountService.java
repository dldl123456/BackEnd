package com.zhizuobiao.class10;

public interface AccountService {

    /**
     * 转账
     *
     * @param fromName 付款人
     * @param toName   收款人
     * @param money    金额
     */
    void transAccount(String fromName, String toName, double money);
}
