package com.zhizuobiao.class6;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Aspect
public class AopAspect {

    // 配置切入点
    @Pointcut("execution(* com.zhizuobiao..*.*(..))")
    public void cutPointA() {
    }

    /**
     * 前置通知
     */
    @Before("cutPointA()")
    public void before() {
        System.out.println("前置通知");
    }

    /**
     * 最终通知，不论是否有异常，都会执行。
     */
    @After("cutPointA()")
    public void after() {
        System.out.println("最终通知");
    }

    /**
     * 异常通知
     *
     * @param e
     */
    @AfterThrowing(value = "cutPointA()", throwing = "e")
    public void afterThrowing(Throwable e) {
        System.out.println("异常通知");
    }

    /**
     * 环绕通知，包含所有的类型，并且可以组织代理方法调用
     *
     * @param pjp
     * @return
     */
//    @Around("cutPointA()")
    public Object around(ProceedingJoinPoint pjp) {
        Object result = null;
        try {
            System.out.println("调用前");
            result.toString();
            result = pjp.proceed();
            System.out.println("调用后");
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            System.out.println("catch");
        } finally {
            System.out.println("finally");
        }
        return result;
    }

    /**
     * 后置通知，获取方法返回值
     *
     * @param value
     */
    @AfterReturning(value = "cutPointA()", returning = "value")
    public void afterReturning(Object value) {

        System.out.println("后置通知:" + value);
    }
}
