package com.zhizuobiao.class10;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountDao accountDao;

//    @Autowired
//    private TransactionTemplate transactionTemplate;


    @Override
    public void transAccount(String fromName, String toName, double money) {

        // 根据事务的特性，2次dao操作放入事务管理中。
        // 开启事务管理，转账业务

//        transactionTemplate.execute(new TransactionCallback<Integer>() {
//            @Override
//            public Integer doInTransaction(TransactionStatus transactionStatus) {

        // 付款
        accountDao.outMoney(fromName, money);

//                String test = null;
//                test.toString();
        int x = 0, y = 0, z = 0;

        z = x / y;

        // 收款
        accountDao.inMoney(toName, money);

//                return 1;
//            }
//        });

    }
}
