package com.zhizuobiao.class3;


import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class JdkProxy {

    //　被代理类
    private PersonDao personDao;

    public JdkProxy(PersonDao personDao) {
        this.personDao = personDao;
    }

    // 返回代理对象
    public PersonDao getProxy() {
        // 生成代理对象
        // 参数说明
        // 1.被代理类的类加载器
        // 2.被代理类实现的接口数组
        // 3.代理对象的回调方法，就是增强代码的地方。
        PersonDao proxy = (PersonDao) Proxy.newProxyInstance(
                this.personDao.getClass().getClassLoader(),
                this.personDao.getClass().getInterfaces(),
                new InvocationHandler() {
                    // Object proxy：代理对象
                    // Method method：代理或拦截的方法
                    // Object[] args：方法的参数
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

                        // 在执行原方法前，添加增强代码
                        System.out.println("DBUtil.openCollection()");
                        Object result = null;
                        try {
                            // 调用被代理类的方法
                            result = method.invoke(personDao, args);
                            // 返回被代理类的方法执行的结果
                        } catch (Throwable e) {
                            System.out.println("异常通知");
                        } finally {
                            System.out.println("最终通知");
                        }

                        // 在执行原方法后，添加增强代码
                        System.out.println("DBUtil.close(Collection conn)");

                        return result;
                    }
                }
        );

        // 返回jdk生成的代理对象
        return proxy;
    }
}
