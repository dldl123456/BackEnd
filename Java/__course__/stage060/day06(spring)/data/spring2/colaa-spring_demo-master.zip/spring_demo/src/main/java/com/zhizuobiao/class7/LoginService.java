package com.zhizuobiao.class7;


import org.springframework.stereotype.Service;

@Service
public class LoginService {

    public void login(){
        System.out.println("登录");
    }

    public void check(){
        System.out.println("检查");

//        String name = null;
//        name.toString();
    }
}
