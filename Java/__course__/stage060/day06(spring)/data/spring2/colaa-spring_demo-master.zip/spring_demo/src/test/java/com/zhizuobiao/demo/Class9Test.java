package com.zhizuobiao.demo;


import com.zhizuobiao.class9.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.*;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring.xml")
public class Class9Test {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    public void test1() {
        System.out.println(jdbcTemplate);
    }

    // batch

    @Test
    public void testBatch() {
        String sql = "insert into user(name) values(?)";
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

            public void setValues(PreparedStatement preparedStatement, int i) throws SQLException {
                preparedStatement.setString(1, "batch:" + i);
            }


            public int getBatchSize() {
                return 10;
            }
        });
    }

    @Test
    public void testQuerys2() {
        String sql = "select * from user";
        List<User> list = jdbcTemplate.query(sql, new RowMapper<User>() {
            @Override
            public User mapRow(ResultSet resultSet, int i) throws SQLException {
                User user = new User();
                user.setId(resultSet.getInt("id"));
                user.setName(resultSet.getString("name"));
                return user;
            }
        });

        list.forEach(user -> {
            System.out.println(user);
        });
    }

    @Test
    public void testQuerys() {
        String sql = "select * from user";
        // 创建集合，添加每行数据到集合中。
        LinkedList<User> userList = new LinkedList<User>();
        jdbcTemplate.query(sql, new RowCallbackHandler() {
            public void processRow(ResultSet resultSet) throws SQLException {
                // 返回数据库中一行的数据，回调
                User user = new User();
                user.setId(resultSet.getInt("id"));
                user.setName(resultSet.getString("name"));

                userList.add(user);
            }
        });

        userList.forEach(user -> {
            System.out.println(user);
        });
        System.out.println(userList.size());
    }

    @Test
    public void testInsert() {
        String sql = "insert into user(name) values(?)";
        Object[] params = new Object[]{"heihei"};
        int code = jdbcTemplate.update(sql, params);
        System.out.println(code);
    }

    @Test
    public void testDelete() {
        String sql = "delete from user where id = ?";
        Object[] params = new Object[]{2};
        int code = jdbcTemplate.update(sql, params);
        System.out.println(code);
    }

    @Test
    public void testUpdate() {
        String sql = "update user set name=? where id = ?";
        Object[] params = new Object[]{"qq", 1};
        int code = jdbcTemplate.update(sql, params);
        System.out.println(code);
    }

    @Test
    public void testQuery() {
        String sql = "select * from user where id = ?";
        Object[] params = new Object[]{1};
        User user = jdbcTemplate.queryForObject(sql, params, new BeanPropertyRowMapper<User>(User.class));
        System.out.println(user);
    }
}
