package com.zhizuobiao.class12;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("accountServiceImpl12")
public class AccountServiceImpl implements AccountService {

    @Autowired
    @Qualifier("accountDaoImpl12")
    private AccountDao accountDao;

    @Override
    @Transactional(isolation = Isolation.DEFAULT, propagation = Propagation.REQUIRED)
    /**
     * 使用注解控制事务的优点：
     * 1. 开发人员达成一致的约定，明确标注事务方法。
     * 2. 保证事务方法的执行时间，尽可能短。
     * 3. 不是所有方法都需要事务，例如：只有一条修改操作、只读操作、不需要事务控制。
     */
    public void transAccount(String fromName, String toName, double money) {

        // 根据事务的特性，2次dao操作放入事务管理中。
        // 开启事务管理，转账业务

        // 付款
        accountDao.outMoney(fromName, money);

//                String test = null;
//                test.toString();
//        int x = 0, y = 0, z = 0;
//        z = x / y;

        // 收款
        accountDao.inMoney(toName, money);

    }
}
