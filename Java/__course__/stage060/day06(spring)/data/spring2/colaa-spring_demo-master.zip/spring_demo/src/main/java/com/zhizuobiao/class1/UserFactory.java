package com.zhizuobiao.class1;

/**
 * Created by Administrator on 2017/8/2 0002.
 */
public class UserFactory {

    public static User createUser() {
        return new User();
    }
}
