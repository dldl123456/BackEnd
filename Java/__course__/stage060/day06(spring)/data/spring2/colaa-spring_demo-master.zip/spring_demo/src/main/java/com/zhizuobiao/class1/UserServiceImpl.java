package com.zhizuobiao.class1;

/**
 * Created by Administrator on 2017/8/2 0002.
 */
public class UserServiceImpl {

    private User user;

    public void init() {
        System.out.println("初始化init");
    }

    public void destroy() {
        System.out.println("销毁destroy");
    }

    public void printName() {
        System.out.println("你好，旺财！");
    }

    public void printUser() {
        System.out.println(user);
    }

    public void setUser(User user) {
        this.user = user;
    }
}
