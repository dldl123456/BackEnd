package com.zhizuobiao.test1;

/**
 *  捕获异常测试
 */
public class TryCatchTest {
    public static int getNumber() {
        try {
            String s = null;
            s.toCharArray();
            System.out.println("a");
        } catch (Throwable e) {
            System.out.println("b");
        } finally {
            System.out.println("c");
        }
        System.out.println("d");
        return 1;
    }

    public static void main(String[] args) {
        System.out.println(getNumber());
    }

}
