package com.zhizuobiao.class5;


import org.springframework.stereotype.Service;

@Service
public class CatDao {

    public int insert() {
        System.out.println("插入");
//        print();

        return 1;
    }

    // 测试直接调用
    public void print(){
        String a = null;
        a.toCharArray();
        System.out.println("测试打印方法");
    }

    public int update() {
        System.out.println("更新");
        return 1;
    }
}
