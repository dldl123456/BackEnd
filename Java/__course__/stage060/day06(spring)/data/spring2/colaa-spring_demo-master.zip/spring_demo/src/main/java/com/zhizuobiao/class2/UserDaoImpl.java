package com.zhizuobiao.class2;


import org.springframework.stereotype.Repository;

@Repository("userDao")
public class UserDaoImpl {

    public void insertUser(){
        System.out.println("insert ok");
    }

    public void getUser(){
        System.out.println("get User ok");
    }
}
