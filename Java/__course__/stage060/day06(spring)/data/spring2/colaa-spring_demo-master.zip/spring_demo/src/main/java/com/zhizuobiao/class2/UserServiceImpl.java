package com.zhizuobiao.class2;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

@Service
public class UserServiceImpl {

    @PostConstruct
    public void testInit() {
        //System.out.println("init a a a aa ");
    }

    @PreDestroy
    public void testDestory() {
       //System.out.println("destory bdbdbb b");
    }

    @Value("gonna")
    private String name;

    @Resource(name = "userDao")
    private UserDaoImpl userDaoImpl;

    public void showName() {
        System.out.println(" = " + name + " = ");
    }

    public void getUser() {
        userDaoImpl.getUser();
    }

    public void saveUser() {
        userDaoImpl.insertUser();
    }

    public void setUserDaoImpl(UserDaoImpl userDaoImpl) {
        this.userDaoImpl = userDaoImpl;
    }
}
