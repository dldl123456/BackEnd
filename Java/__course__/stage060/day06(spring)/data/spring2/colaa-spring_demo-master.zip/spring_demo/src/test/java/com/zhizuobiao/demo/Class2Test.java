package com.zhizuobiao.demo;


import com.zhizuobiao.class2.UserServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by Administrator on 2017/8/2 0002.
 */
public class Class2Test {
    private ApplicationContext cxt;

    @Before
    public void init() {
        // 实例化spring容器
        cxt = new ClassPathXmlApplicationContext("beans.xml");
    }

    @Test
    public void test1() {

        UserServiceImpl service = (UserServiceImpl) cxt.getBean("userServiceImpl");

        service.getUser();

        service.showName();
    }
}
