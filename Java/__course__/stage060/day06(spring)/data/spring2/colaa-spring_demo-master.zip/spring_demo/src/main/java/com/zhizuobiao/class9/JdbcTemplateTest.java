package com.zhizuobiao.class9;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class JdbcTemplateTest {


    public static void testInsert() {
        // 创建数据源
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        // 设置参数
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/jdbc");
        dataSource.setUsername("root");
        dataSource.setPassword("123456");

        // 使用spring的jdbc模板
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);


        String sql = "insert into user(name) values(?)";
        Object[] params = new Object[]{"xiaoxiao"};
        jdbcTemplate.update(sql, params);
    }

    public static void main(String[] args) {

        if (true) {
            testInsert();
            return;
        }
        // 创建数据源
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        // 设置参数
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/jdbc");
        dataSource.setUsername("root");
        dataSource.setPassword("123456");

        // 使用spring的jdbc模板
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        // 执行数据库操作
        jdbcTemplate.execute("create table user(" +
                "id int PRIMARY KEY auto_increment," +
                "name varchar(20))");

    }
}
