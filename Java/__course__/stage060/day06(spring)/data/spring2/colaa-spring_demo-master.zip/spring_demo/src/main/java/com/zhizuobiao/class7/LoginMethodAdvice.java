package com.zhizuobiao.class7;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

/**
 * 环绕通知
 */
public class LoginMethodAdvice implements MethodInterceptor {
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {

        System.out.println("before");
        Object result = methodInvocation.proceed();
        System.out.println("after");

        return result;
    }
}
