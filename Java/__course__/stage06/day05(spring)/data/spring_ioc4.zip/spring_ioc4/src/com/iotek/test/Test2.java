package com.iotek.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.iotek.bean.Bean;



public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       //ʵ����spring����===�൱�ڹ�����,ʵ�����ܶ����.���ҹ�����Щ����.
		
	  ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
	  Bean bean=(Bean)context.getBean("bean");
	  System.out.println(bean.getId()+bean.getName());
	  System.out.println(bean.getBean1().getName());
	  
	  
	  Bean b1=(Bean)context.getBean("b1");
	  System.out.println(b1.getBean1().getName());
		
	
		
	}

}
