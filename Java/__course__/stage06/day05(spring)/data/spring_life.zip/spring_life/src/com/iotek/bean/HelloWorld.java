package com.iotek.bean;

public class HelloWorld {
	private String name;
	public HelloWorld() {
		// TODO Auto-generated constructor stub
		System.out.println("constructor");
	}
    
	public HelloWorld(String name) {
		super();
		this.name = name;
	}
    public void init(){
    	System.out.println("init...");
    }
    public void destroy(){
    	System.out.println("destory...");
    }
	public void sayHello() {
		System.out.println(this.name+" say hello..");
	}
}
