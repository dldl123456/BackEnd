package com.iotek.bean;

public class HelloWorld {
	private String name;
	
	public void setName(String name) {
		System.out.println("setter ע��");
		this.name = name;
	}

	public HelloWorld() {
		// TODO Auto-generated constructor stub
		System.out.println("constructor");
	}

	public void sayHello() {
		System.out.println(this.name+" say hello..");
	}
}
