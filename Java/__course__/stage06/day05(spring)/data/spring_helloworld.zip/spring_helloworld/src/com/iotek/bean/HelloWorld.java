package com.iotek.bean;

public class HelloWorld {
	public HelloWorld() {
		// TODO Auto-generated constructor stub
		System.out.println("constructor");
	}

	public void sayHello() {
		System.out.println("say hello..");
	}
}
