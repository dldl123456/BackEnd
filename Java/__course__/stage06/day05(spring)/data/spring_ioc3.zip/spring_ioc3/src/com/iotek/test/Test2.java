package com.iotek.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.iotek.bean.TestCollections;





public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       //ʵ����spring����===�൱�ڹ�����,ʵ�����ܶ����.���ҹ�����Щ����.
		
	  ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
	  TestCollections cs=(TestCollections)context.getBean("cs");
	  System.out.println(cs.getId());
	  System.out.println(cs.getArray());
	  for(String temp:cs.getArray()){
		  System.out.println(temp);
	  }
	  System.out.println(cs.getListValues());
	  System.out.println(cs.getSetValues());
	  System.out.println(cs.getMapValues());
	  System.out.println(cs.getPropValues());
		
	
		
	}

}
