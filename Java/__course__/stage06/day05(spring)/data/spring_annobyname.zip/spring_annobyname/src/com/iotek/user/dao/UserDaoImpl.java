package com.iotek.user.dao;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.iotek.bean.User;
@Repository(value="userDaoImpl")
public class UserDaoImpl implements UserDao {

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
          System.out.println("userDaoImpl....");
	}

}
