package com.iotek.user.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.iotek.bean.User;
import com.iotek.user.dao.UserDao;
import com.iotek.user.dao.UserDaoImpl;
@Service(value="userServiceImpl")
public class UserServiceImpl implements UserService {
    private UserDao userDao;
    @Resource(name="userDaoImpl")
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("service...");
            userDao.addUser(user);;
	}

}
