package com.iotek.user.dao;

import com.iotek.bean.User;

public interface UserDao {
    public void addUser(User user);
}
