package com.iotek.user.service;

import com.iotek.bean.User;

public interface UserService {
	 public void addUser(User user);
}
