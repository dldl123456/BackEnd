package com.iotek.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.iotek.bean.User;
import com.iotek.user.controller.UserController;
import com.iotek.user.dao.UserDao;
import com.iotek.user.service.UserService;



public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       //ʵ����spring����===�൱�ڹ�����,ʵ�����ܶ����.���ҹ�����Щ����.
		//ClassPathXmlApplicationContextĬ��·����src��
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
	/*	UserService userService=(UserService)context.getBean("userServiceImpl");
		userService.addUser(new User());*/
		
		
		UserController uc=(UserController)context.getBean("userController");
	
	    uc.register();
		
	}

}
