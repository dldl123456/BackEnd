package com.iotek.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.iotek.bean.User;
import com.iotek.user.service.UserService;

@Controller(value="userController")
public class UserController {
     private UserService userService;
     @Autowired
     @Qualifier(value="userServiceImpl")
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
    public void register(){
    	System.out.println("controller...");
    	userService.addUser(new User());
    }
     
}
