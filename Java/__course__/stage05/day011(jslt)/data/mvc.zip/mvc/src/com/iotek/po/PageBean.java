package com.iotek.po;

import java.util.List;
/**
 * ��Ʒ�ҳ���
 * @author Administrator
 * ����:ģ��;
 *
 */
public class PageBean<T> {
    private Integer pc; //��ǰҳ��;
    private Integer tr; //�ܼ�¼��;
    private Integer ps; //ҳ�Ĵ�С;
    private Integer tp; //��ҳ��;
    private List<T> beanList;
	public Integer getPc() {
		return pc;
	}
	public void setPc(Integer pc) {
		this.pc = pc;
	}
	public Integer getTr() {
		return tr;
	}
	public void setTr(Integer tr) {
		this.tr = tr;
	}
	public Integer getPs() {
		return ps;
	}
	public void setPs(Integer ps) {
		this.ps = ps;
	}
	//100����¼  ҳ�Ĵ�С10,  ��10ҳ  100/10  10
	//102����¼   ҳ�Ĵ�С10,  ��11ҳ  100%10  2
	public Integer getTp() {
		int tp=tr/ps;
		return tr%ps==0?tp:tp+1;
	}
	/*
	public void setTp(Integer tp) {
		this.tp = tp;
	}
	*/
	public List<T> getBeanList() {
		return beanList;
	}
	public void setBeanList(List<T> beanList) {
		this.beanList = beanList;
	}
	@Override
	public String toString() {
		return "PageBean [pc=" + pc + ", tr=" + tr + ", ps=" + ps + ", tp="
				+ tp + ", beanList=" + beanList + "]";
	}
    
}
