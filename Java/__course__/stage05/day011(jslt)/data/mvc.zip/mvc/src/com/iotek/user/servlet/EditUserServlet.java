package com.iotek.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iotek.po.User;
import com.iotek.user.service.UserService;
import com.iotek.user.service.UserServiceImpl;


public class EditUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService=new UserServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   	// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		User user=userService.getUserById(id);
		request.setAttribute("user", user);
		request.getRequestDispatcher("update.jsp").forward(request, response);
	}

}
