package com.iotek.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iotek.po.PageBean;
import com.iotek.po.User;
import com.iotek.utils.DBUtils;

/**
 * Dao data  access Object===>�����ݴ򽻵�;
 * CRUD����
 * @author Administrator
 *
 */
public class UserDaoImpl implements UserDao {
    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;
    
	@Override
	public List<User> queryAllUser() {
		// TODO Auto-generated method stub
		try {
			conn=DBUtils.getConnection();
			String sql="select id,username,password,confirmpassword,email,phone from tb_user";
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			User user=null;
			List<User> users=new ArrayList();
			while(rs.next()){
				user=new User();
				user.setId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setConfirmpassword(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setPhone(rs.getString(6));
				users.add(user);
			}
			return users;
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			return null;
		}
	

	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		try {
			conn=DBUtils.getConnection();
			String sql="insert into tb_user(username,password,confirmpassword,email,phone) "
					+ "values(?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getConfirmpassword());
			pstmt.setString(4, user.getEmail());
			pstmt.setString(5, user.getPhone());
			int a=pstmt.executeUpdate();
			return a;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return -1;    //���
		
	}

	@Override
	public int deleteUserById(int id) {
		// TODO Auto-generated method stub
		try {
			conn=DBUtils.getConnection();
			String sql="delete from tb_user where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			int a=pstmt.executeUpdate();
			return a;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return -1;    //���
	}

	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		try {
			conn=DBUtils.getConnection();
			String sql="update tb_user set userName=?,password=?,confirmpassword=?,email=?,phone=? where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getConfirmpassword());
			pstmt.setString(4, user.getEmail());
			pstmt.setString(5, user.getPhone());
			pstmt.setInt(6, user.getId());
			int a=pstmt.executeUpdate();
			return a;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return -1;    //���
	}

	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		try {
		conn=DBUtils.getConnection();
		String sql="select id,username,password,confirmpassword,email,phone from tb_user where id=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs=pstmt.executeQuery();
		User user=new User();
		while(rs.next()){
			user.setId(rs.getInt(1));
			user.setUsername(rs.getString(2));
			user.setPassword(rs.getString(3));
			user.setConfirmpassword(rs.getString(4));
			user.setEmail(rs.getString(5));
			user.setPhone(rs.getString(6));
		}
		return user;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public boolean login(String userName, String password) {
		// TODO Auto-generated method stub
		try {
			conn=DBUtils.getConnection();
			String sql="select 1 from tb_user where username=? and password=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			rs=pstmt.executeQuery();
			while(rs.next()){
			   return true;
			}
			
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		return false;
		
	}


	@Override
	public int countUser() {
		// TODO Auto-generated method stub
		try {
			conn=DBUtils.getConnection();
			String sql="select count(1) cnt from tb_user";
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			int cnt=0;
			while(rs.next()){
				cnt=rs.getInt("cnt");
			}
			return cnt;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return -1;
	}


	@Override
	public PageBean<User> queryUserByPage(int pc, int ps) {
		// TODO Auto-generated method stub
		try {
			List<User> users=new ArrayList();
			conn=DBUtils.getConnection();
			PageBean<User> pb=new PageBean();
			pb.setPc(pc);
			pb.setPs(ps);
			int tr=countUser();
			pb.setTr(tr);
			String sql="select * from tb_user limit "+(pc-1)*ps+","+ps;
			System.out.println("sql="+sql);
			rs=pstmt.executeQuery(sql);
			User user=null;
			while(rs.next()){
				 user=new User();
				 user.setId(rs.getInt(1));
				 user.setUsername(rs.getString(2));
				 user.setPassword(rs.getString(3));
				 user.setConfirmpassword(rs.getString(4));
				 user.setEmail(rs.getString(5));
				 user.setPhone(rs.getString(6));
				 users.add(user);
			}
			pb.setBeanList(users);
			return pb;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}

}
