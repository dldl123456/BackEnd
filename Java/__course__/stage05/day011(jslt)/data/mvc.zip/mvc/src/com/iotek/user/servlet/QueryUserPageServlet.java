package com.iotek.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iotek.po.PageBean;
import com.iotek.po.User;
import com.iotek.user.service.UserService;
import com.iotek.user.service.UserServiceImpl;

public class QueryUserPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService=new UserServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int pc=getPc(request,response);
		int ps=3;  //ÿҳ�Ĵ�С3����¼;
		PageBean<User> pageBean=userService.queryUserByPage(pc, ps);
		request.setAttribute("pb", pageBean);
		request.getRequestDispatcher("userlist.jsp").forward(request, response);
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	//��ȡ��ǰҳ
	protected int getPc(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String pc=request.getParameter("pc");
	
		if(pc==null||pc.trim().isEmpty()){
			return 1;
		}
		return Integer.parseInt(pc);
	}

}
