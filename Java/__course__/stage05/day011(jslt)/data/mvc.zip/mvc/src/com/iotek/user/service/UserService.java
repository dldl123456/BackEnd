package com.iotek.user.service;

import java.util.List;

import com.iotek.po.PageBean;
import com.iotek.po.User;

public interface UserService {
	 public List<User> queryAllUser();
     public int addUser(User user);
     public int deleteUserById(int id);
     public int updateUser(User user);
     public User getUserById(int id);
     public boolean login(String userName,String password);
  
     //�ܼ�¼��;
     public int countUser();
     //��ҳ��ѯ;��ѯһҳ������;
     public PageBean<User> queryUserByPage(int pc,int ps);
}
