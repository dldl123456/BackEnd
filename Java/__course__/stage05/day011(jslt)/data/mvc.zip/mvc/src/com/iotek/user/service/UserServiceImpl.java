package com.iotek.user.service;

import java.util.List;

import com.iotek.po.PageBean;
import com.iotek.po.User;
import com.iotek.user.dao.UserDao;
import com.iotek.user.dao.UserDaoImpl;
public class UserServiceImpl implements UserService {
    private UserDao userDao=new UserDaoImpl();
	@Override
	public List<User> queryAllUser() {
		// TODO Auto-generated method stub
		return userDao.queryAllUser();
	}
	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}

	@Override
	public int deleteUserById(int id) {
		// TODO Auto-generated method stub
		return userDao.deleteUserById(id);
	}

	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		return userDao.updateUser(user);
	}

	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		return userDao.getUserById(id);
	}
	@Override
	public boolean login(String userName, String password) {
		// TODO Auto-generated method stub
		return userDao.login(userName, password);
	}
	@Override
	public int countUser() {
		// TODO Auto-generated method stub
		return userDao.countUser();
	}
	@Override
	public PageBean<User> queryUserByPage(int pc, int ps) {
		// TODO Auto-generated method stub
		return userDao.queryUserByPage(pc, ps);
	}

}
