package com.iotek.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBUtils {
     private static String driver;
     private static String url;
     private static String user;
     private static String password;
     private static Properties prop;
     static{
    	 prop=new Properties();
    	 try {
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("db.properties"));
			driver=prop.getProperty("driver");
			url=prop.getProperty("url");
			user=prop.getProperty("user");
			password=prop.getProperty("password");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     }
     public static  Connection getConnection(){
    	 try {
    		Class.forName(driver);   //jdbc4.0 Ĭ�Ͽ��Բ�д.web tomcat����
        	Connection conn= DriverManager.getConnection(url, user, password);
        	System.out.println("���ӳɹ�"+conn);
        	return conn;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	 return null;
    	
    	 
     }
}
