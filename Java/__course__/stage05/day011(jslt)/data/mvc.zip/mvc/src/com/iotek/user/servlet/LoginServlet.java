package com.iotek.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.iotek.user.service.UserService;
import com.iotek.user.service.UserServiceImpl;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService=new UserServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName=request.getParameter("username");
		String psw=request.getParameter("psw");
		HttpSession session=request.getSession();
		boolean flag=userService.login(userName, psw);
		if(flag){
			session.setAttribute("username", userName);
			response.sendRedirect("query.do");  //��¼�ɹ�,��ʾ�����û���Ϣ;
		}else{
			response.sendRedirect("login.jsp");
		}
		
	}

}
