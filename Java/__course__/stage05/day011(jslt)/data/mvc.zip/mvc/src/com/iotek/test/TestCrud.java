package com.iotek.test;

import java.util.List;

import org.junit.Test;

import com.iotek.po.User;
import com.iotek.user.dao.UserDao;
import com.iotek.user.dao.UserDaoImpl;
import com.iotek.utils.DBUtils;

public class TestCrud {
	  @Test
      public void testGetConnection(){
    	  DBUtils.getConnection();
      }
	  @Test
	  public void testAddUser(){
		  UserDao userDao=new UserDaoImpl();
		  userDao.addUser(new User("lyp","fendou","fendou","lv@11.com","18888"));
		  
	  }
	  
	  @Test
	  public void testDelete(){
		  UserDao userDao=new UserDaoImpl();
		   userDao.deleteUserById(20);
		  
	  }
	  
	  @Test
	  public void testUpdateUser(){
		  UserDao userDao=new UserDaoImpl();
		  userDao.updateUser(new User(19,"lyp","fendou","fendou","lv@11.com","18888"));
		  
	  }
	  
	  @Test
	  public void testGetUserById(){
		  UserDao userDao=new UserDaoImpl();
		  User user=userDao.getUserById(19);
		  System.out.println(user);
		  
	  }
	  
	  @Test
	  public void testQueryAllUser(){
		  UserDao userDao=new UserDaoImpl();
		  List<User> user=userDao.queryAllUser();
		  System.out.println(user);
		  
	  }
	  @Test
	  public void testCountUser(){
		  UserDao userDao=new UserDaoImpl();
		 int cnt=userDao.countUser();
		  System.out.println(cnt);
		  
	  }
}
