package com.iotek.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iotek.po.User;
import com.iotek.user.service.UserService;
import com.iotek.user.service.UserServiceImpl;
/**
 * ���Ʋ�:
 * @author Administrator
 *
 */
public class AddUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	private UserService userService=new UserServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName=request.getParameter("username");
		String psw=request.getParameter("psw");
		String confirmpsw=request.getParameter("confrimpsw");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		
		User user=new User(userName,psw,confirmpsw,email,phone);
		int a=userService.addUser(user);
		if(a>0){
			response.sendRedirect("login.jsp");
		}else{
			response.sendRedirect("adduser.jsp");
		}
		
		
		
		
		
	}

}
