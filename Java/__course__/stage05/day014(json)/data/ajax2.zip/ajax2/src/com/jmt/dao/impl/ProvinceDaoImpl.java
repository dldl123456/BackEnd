package com.jmt.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jmt.bean.City;
import com.jmt.bean.Province;
import com.jmt.dao.ProvinceDao;
import com.jmt.db.DBUtil;

public class ProvinceDaoImpl implements ProvinceDao {
	
	public List<Province> getProvince() {
		DBUtil db=new DBUtil();
		List Provinces=new ArrayList();
		Connection connection=DBUtil.getConnection();
		
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=connection.prepareStatement("select * from t_province");
			rs=pst.executeQuery();
			while(rs.next()){
				Province province=new Province();
				province.setId(rs.getInt(1));
				province.setName(rs.getString(2));
				Provinces.add(province);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Provinces;
	}
	
	public List getCityByPid(int id){
		
		DBUtil db=new DBUtil();
		List citys=new ArrayList();
		Connection connection=DBUtil.getConnection();
		
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=connection.prepareStatement("select id,pid,name from t_city where pid=?");
			pst.setInt(1, id);
			rs=pst.executeQuery();
			while(rs.next()){
				City city=new City();
				city.setId(rs.getInt(1));
				city.setPid(rs.getInt(2));
				city.setName(rs.getString(3));
				citys.add(city);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return citys;
		
	}

}
