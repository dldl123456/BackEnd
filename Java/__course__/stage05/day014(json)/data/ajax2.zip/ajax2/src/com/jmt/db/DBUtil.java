package com.jmt.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil 
{
	/*
	 * ����ʧ�ܷ��ؿշ��򷵻�conn
	 * Context�Ǹ��ӿڣ�ʵ������InitialContext
	 * Object lookup(String name) ����ָ���Ķ��� 
	 */
	public static Connection getConnection() 
	{
		Context initCtx;
		Connection conn=null;
		try 
		{
			initCtx=new InitialContext();
			Context envCtx=(Context) initCtx.lookup("java:comp/env");
			DataSource ds=(DataSource) envCtx.lookup("jdbc/oracle");
			try {
				conn=ds.getConnection();
				
				System.out.println("xxx"+conn.toString());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		catch (NamingException e) 
		{
			e.printStackTrace();
		}
		return conn;
	}
	
	public Statement getStm(){  
		  try {
			return getConnection().createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		  
	  }
	  
	  public static PreparedStatement getPstm(String sql ){
		  
		  try {
			return getConnection().prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	  }
	  
	  public PreparedStatement getPstm(String sql,Object[] values){
		  Connection conn=this.getConnection();
		  PreparedStatement psm=null;
		  try {
			 psm=conn.prepareStatement(sql);
			for(int i=0;i<values.length;i++){
				
				psm.setObject(i+1, values[i]);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return  psm;
		  
		  
	  }
	  
	  public ResultSet getRsByPrepared(String sql,Object[] values){
		  
		  try {
			return getPstm(sql,values).executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		  
		  
	  }
	  
	  public int execute(String sql){  
		  Connection conn =this.getConnection();
		  PreparedStatement pst=null;
		   try {
			   pst=conn.prepareStatement(sql);
			  return pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}finally{
			closePstmt(pst);
			closeconn(conn);
			
		}
		  
		  
	  }
	  
public int execute(String sql , Object[] values){
		  
	 Connection conn =this.getConnection();
	  PreparedStatement pst=null;
	   try {
		   pst=getPstm(sql,values);
		  return pst.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	}finally{
		closePstmt(pst);
		closeconn(conn);
		
	} 
	  }

public void closePstmt(PreparedStatement pstmt){
	 if(pstmt!=null){ 
		 try {
			pstmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
}

public void closeconn(Connection conn){
	 if(conn!=null){
		 try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	 }
	 
}

public void closeRs(ResultSet rs){
	 
	 if(rs!=null){
		 try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	 }
	 
	 
}

public void closeStatement(Statement stmt){
	 
	 if(stmt!=null){	 
		 try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 
	 }
	 
	 
}

}
