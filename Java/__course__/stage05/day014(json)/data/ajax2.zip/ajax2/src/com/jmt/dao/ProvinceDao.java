package com.jmt.dao;

import java.util.List;

public interface ProvinceDao {
	public List getProvince();
	
	public List getCityByPid(int id);

}
