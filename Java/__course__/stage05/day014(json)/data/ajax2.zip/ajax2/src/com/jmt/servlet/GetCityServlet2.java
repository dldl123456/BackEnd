package com.jmt.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jmt.bean.City;
import com.jmt.bean.Province;
import com.jmt.dao.ProvinceDao;
import com.jmt.factory.DaoFactory;

public class GetCityServlet2 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
		
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/xml;charset=utf-8");
		response.setHeader("Cache-Control","no-cache"); //HTTP 1.1 
		response.setHeader("Pragma","no-cache"); //HTTP 1.0 
		response.setDateHeader ("Expires", 0); //prevents caching at the proxy server  
		PrintWriter out=response.getWriter();
		String cid=request.getParameter("id");
		int id=0;
		if(cid!=null&&cid!=""){
		 id=Integer.parseInt(cid);		
		}
		
		DaoFactory df=DaoFactory.getInstance();
		ProvinceDao provinceDao=df.getProvinceDaoImpl();
		List<City> Provinces=provinceDao.getCityByPid(id);
		StringBuffer bf=new StringBuffer();
		bf.append("<?xml version='1.0' encoding='utf-8' ?>");
		bf.append("<citys>");
		for(City c:Provinces){
			bf.append("<city>");
			   bf.append("<id>");
			   bf.append(c.getId());
			   bf.append("</id>");
			   bf.append("<name>");
			   bf.append(c.getName());
			   bf.append("</name>");
			bf.append("</city>");
			
		
		}
		
		bf.append("</citys>");
		System.out.println(bf.toString());
		out.print(bf.toString());
		out.flush();
		out.close();
		
	}

}
