package com.jmt.factory;

import java.io.IOException;
import java.util.Properties;

import com.jmt.dao.ProvinceDao;






public class DaoFactory 
{
	private DaoFactory(){}
	private static DaoFactory factory=null;
	/*
	 * java.util �� Properties��ʾ��һ���־õ����Լ���
	 * Properties �ɱ��������л�����м��ء�
	 * �����б���ÿ���������Ӧֵ����һ���ַ�����
	 * */
	private static Properties properties;
	public static synchronized DaoFactory getInstance()
	{
		if(factory!=null)
		{
			return factory;
		}
		else
		{
			factory=new DaoFactory();
			return factory;
		}		
	}
	
	static
	{
		properties=new Properties();
		try 
		{
			properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("dao.properties"));
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public ProvinceDao getProvinceDaoImpl()
	{
		ProvinceDao provinceDao=null;
		String provinceDaoImpl=properties.getProperty("provinceDao");
		try 
		{
			provinceDao=(ProvinceDao)Class.forName(provinceDaoImpl).newInstance();
		} 
		catch (InstantiationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IllegalAccessException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return provinceDao;
	}
}
