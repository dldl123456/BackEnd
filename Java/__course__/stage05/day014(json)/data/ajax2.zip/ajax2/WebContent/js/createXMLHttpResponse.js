var xmlHttpreq=false;
	 function createXMLResponse(){
	  if(window.XMLHttpRequest){
	            //Mozilla
	            xmlHttpreq=new XMLHttpRequest();
	        }else{
	            //IE
	            if(window.ActiveXObject){
	                try{    //IE 6����
	                     xmlHttpreq=new ActiveXObject("Msxml2.XMLHttp");
	                }catch(e){
	                    try{     //IE 6����
	                        xmlHttpreq=new ActiveXObject("Microsoft.XMLHttp");
	                    }catch(e){
	                    }
	                }
	            }
	        }
	    }