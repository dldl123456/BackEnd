package com.iotek.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;


public class JsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("utf-8");
		//������Ӧ����json ����
		response.setContentType("application/json");
		PrintWriter out=response.getWriter();
		String userName=request.getParameter("username");
		JSONObject json=new JSONObject();
		if("liayin".equals(userName)){
		    json.put("uname", userName+"��ע��");
		}else{
			json.put("uname", userName+"����ʹ��");
		}
		System.out.println(json.toString());
		out.println(json);
		out.flush();
		out.close();
		
		
	}

}
