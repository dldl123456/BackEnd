package com.iotek.json;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class TestJson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //TestJsonObject();
		//testObjectUser();
		//testJsonArray();
		Map<String,User> map=new HashMap();
	     User user1=new User("liayin1","fendou","�Ϻ�1");
	     User user2=new User("liayin2","fendou","�Ϻ�2");
	     map.put("user1", user1);
	     map.put("user2", user2);
	     JSONArray jarr=new JSONArray();
	     jarr.add(map);
	     System.out.println(jarr.toString());
	}

	private static void testJsonArray() {
		JSONArray jarr=new JSONArray();
		jarr.add(new User("liayin1","fendou","sh"));
		jarr.add(new User("liayin2","fendou","sh"));
		jarr.add(new User("liayin3","fendou","sh"));
		
		System.out.println(jarr.toString());
	}

	private static void testObjectUser() {
		JSONObject jsonObject=new JSONObject();
        jsonObject.put("1", new User("liayin1","fendou","sh"));
        jsonObject.put("2", new User("liayin2","fendou","sh"));
        jsonObject.put("3", new User("liayin3","fendou","sh"));
        System.out.println(jsonObject.toString());  //�ַ�������json��ʽ�ַ���
	}

	private static void TestJsonObject() {
		JSONObject jsonObject=new JSONObject();
        jsonObject.put("name", "С��");
        jsonObject.put("age", 21);
        jsonObject.put("address", "�Ϻ�");
        System.out.println(jsonObject.toString());  //�ַ�������json��ʽ�ַ���
	}

}
