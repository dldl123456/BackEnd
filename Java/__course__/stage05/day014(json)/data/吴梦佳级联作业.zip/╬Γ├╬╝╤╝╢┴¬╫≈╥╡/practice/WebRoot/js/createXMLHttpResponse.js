var xhr=false;
	 function createXMLResponse(){
	  if(window.XMLHttpRequest){
	            //Mozilla
	            xhr=new XMLHttpRequest();
	        }else{
	            //IE
	            if(window.ActiveXObject){
	                try{    //IE 6����
	                   xhr=new ActiveXObject("Msxml2.XMLHttp");
	                }catch(e){
	                    try{     //IE 6����
	                        xhr=new ActiveXObject("Microsoft.XMLHttp");
	                    }catch(e){
	                    }
	                }
	            }
	        }
	    }