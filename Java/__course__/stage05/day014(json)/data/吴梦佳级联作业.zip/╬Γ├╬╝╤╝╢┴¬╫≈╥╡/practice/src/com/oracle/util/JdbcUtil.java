package com.oracle.util;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;


public class JdbcUtil {
	private static Connection conn=null;
	private static Properties pro=null;
	static{
		try {
			pro=new Properties();
			pro.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("DB.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static Connection getConn(){
			try {
				DataSource ds=BasicDataSourceFactory.createDataSource(pro);
				conn=ds.getConnection();
				return conn;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
				
	}
	public static void releaseConn(Connection conn,PreparedStatement pst){
		
		
			try {
				if(conn!=null)
				conn.close();
				if(pst!=null)
					pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	public static void releaseConn(Connection conn,PreparedStatement pst,ResultSet rs){
		
		
		try {
			if(conn!=null)
			conn.close();
			if(pst!=null)
				pst.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
   }
	public static Map<String,String> getTypes( ){
		Map<String,String> map=new HashMap<String,String>();
		map.put("1", "JAVA方向");
		map.put("2", "#.NET方向");
		map.put("3", "心情日记");
		map.put("4", "励志文章");
		return map;
		
	}
	public static Map<String,String> getRelation( ){
		Map<String,String> map=new HashMap<String,String>();
		map.put("1", "家人");
		map.put("2", "领导");
		map.put("3", "师长");
		map.put("4", "朋友");
		map.put("5", "同学");
		map.put("6", "同事");
		return map;
		
	}
	//String ת��Ϊutil.date������
	public static Date stringToDate(String s){
		SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		try {
			return f.parse(s);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	//util Dateת��Ϊsql.date����
	public static java.sql.Date dateToDate(Object object){
		//SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return new java.sql.Date(((Date) object).getTime());
	}
	//Date����ת��ΪString����
	public static String dateToString(Date d){
		SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return f.format(d);
	}
	
}
