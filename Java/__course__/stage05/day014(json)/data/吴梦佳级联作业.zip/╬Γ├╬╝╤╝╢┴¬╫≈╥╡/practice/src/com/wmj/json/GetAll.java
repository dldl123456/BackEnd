package com.wmj.json;

import java.util.ArrayList;
import java.util.List;

public class GetAll {

	private static 		List<City> city=new ArrayList<City>();
	private static List<Area> area=new ArrayList<Area>();
	private static 		List<Province> list=new ArrayList<Province>();

	static{
		Province pro=new Province(1,"湖北");
		Province pro1=new Province(2,"上海");
		Province pro2=new Province(3,"江苏");
		Province pro3=new Province(4,"河南");
		Province pro4=new Province(5,"吉林省");
         list.add(pro);
         list.add(pro1);
          list.add(pro2);
         list.add(pro3);
            list.add(pro4);
            
            City city1=new City(1,1,"武汉");
            City city2=new City(2,1,"襄阳");
            City city7=new City(7,1,"武汉fdsfwe");

            City city3=new City(3,2,"海口");
            City city4=new City(4,3,"苏州");
            City city5=new City(5,3,"南京");
            City city6=new City(6,4,"郑州");
          /*  city.add(1, city1);
            city.add(2, city2);
            city.add(3, city3);
            city.add(4, city4);
            */
          city.add(city1);
          city.add(city2);
          city.add(city3);
          city.add(city4);
          city.add(city5);
          city.add(city6);
          city.add(city7);
            
		Area a1=new Area(1,1,"武昌");
		Area a2=new Area(2,4,"昆山");
		Area a3=new Area(3,2,"襄城");
		Area a4=new Area(4,2,"樊城");
		Area a5=new Area(5,2,"襄州");
		Area a6=new Area(6,2,"宜城");
		Area a7=new Area(7,6,"平顶山");
		Area a8=new Area(8,6,"济源");
		area.add(a1);
		area.add(a2);
		area.add(a3);
		area.add(a4);
		area.add(a5);
		area.add(a6);
		area.add(a7);
		area.add(a8);
		
		
		
	}
	public static List<Province> getProvince(){
		return list;
	}
	public static List<City> getCity(int id){
        List<City> list=new ArrayList<City>();
        for(int i=0;i<city.size();i++){
        	if(city.get(i).getProvinceId()==id)
        		list.add(city.get(i));
        }
       return list;
	}
	public static List<Area> getArea(int id){
		
		 List<Area> list=new ArrayList<Area>();
	        for(int i=0;i<city.size();i++){
	        	if(area.get(i).getCityId()==id)
	        		list.add(area.get(i));
	        }
	       return list;
	}
	
}
