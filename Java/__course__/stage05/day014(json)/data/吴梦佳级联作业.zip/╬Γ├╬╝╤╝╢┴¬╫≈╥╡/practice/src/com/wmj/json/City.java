package com.wmj.json;

import java.io.Serializable;

public class City implements Serializable {

	private int cityId;
	private int provinceId;
	private String cityCode;
	private String cityName;
	public City(){}
	public City(int cityId,int provinceId,  String cityName) {
		super();
		this.provinceId = provinceId;
		this.cityId = cityId;
		this.cityName = cityName;
	}
	public City(int cityId, int provinceId, String cityCode, String cityName) {
		super();
		this.cityId = cityId;
		this.provinceId = provinceId;
		this.cityCode = cityCode;
		this.cityName = cityName;
	}
	/**
	 * @return the cityId
	 */
	public int getCityId() {
		return cityId;
	}
	/**
	 * @param cityId the cityId to set
	 */
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	/**
	 * @return the provinceId
	 */
	public int getProvinceId() {
		return provinceId;
	}
	/**
	 * @param provinceId the provinceId to set
	 */
	public void setProvinceId(int provinceId) {
		this.provinceId = provinceId;
	}
	/**
	 * @return the cityCode
	 */
	public String getCityCode() {
		return cityCode;
	}
	/**
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "City [cityCode=" + cityCode + ", cityId=" + cityId
				+ ", cityName=" + cityName + ", provinceId=" + provinceId + "]";
	}
	
	
	
}
