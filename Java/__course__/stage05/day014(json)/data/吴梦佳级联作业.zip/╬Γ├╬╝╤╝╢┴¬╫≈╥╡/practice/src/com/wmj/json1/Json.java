package com.wmj.json1;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class Json {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JSONObject  dataJson=new JSONObject();
		dataJson.put("1", "aaa");
		JSONObject  response=dataJson.getJSONObject("response");
		JSONArray data=response.getJSONArray("data");
		JSONObject info=data.getJSONObject(0);
		String province=info.getString("province");
		String city=info.getString("city");
		String district=info.getString("district");
		String address=info.getString("address"); 
		System.out.println(province+city+district+address);

	}

}
