package com.wmj.json;

import java.io.Serializable;

public class Area implements Serializable {

	private int areaId;
	private int cityId;
	private String areaCode;
	private String areaName;
	public Area(){}
	public Area(int areaId,int cityId,  String areaName) {
		super();
		this.cityId = cityId;
		this.areaId = areaId;
		this.areaName = areaName;
	}
	public Area(int areaId, int cityId, String areaCode, String areaName) {
		super();
		this.areaId = areaId;
		this.cityId = cityId;
		this.areaCode = areaCode;
		this.areaName = areaName;
	}
	/**
	 * @return the areaId
	 */
	public int getAreaId() {
		return areaId;
	}
	/**
	 * @param areaId the areaId to set
	 */
	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}
	/**
	 * @return the cityId
	 */
	public int getCityId() {
		return cityId;
	}
	/**
	 * @param cityId the cityId to set
	 */
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	/**
	 * @return the areaCode
	 */
	public String getAreaCode() {
		return areaCode;
	}
	/**
	 * @param areaCode the areaCode to set
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	/**
	 * @return the areaName
	 */
	public String getAreaName() {
		return areaName;
	}
	/**
	 * @param areaName the areaName to set
	 */
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Area [areaCode=" + areaCode + ", areaId=" + areaId
				+ ", areaName=" + areaName + ", cityId=" + cityId + "]";
	}
	
}
