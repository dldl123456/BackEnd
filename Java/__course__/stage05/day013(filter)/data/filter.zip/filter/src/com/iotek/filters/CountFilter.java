package com.iotek.filters;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class CountFilter
 */
public class CountFilter implements Filter {
     private ServletContext app;
    /**
     * Default constructor. 
     */
    public CountFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}
	

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
	    //1.��ȡapplication�е�map
		Map<String,Integer> map=(Map<String,Integer>)app.getAttribute("map");
		//2.��ȡ�ͻ���IP��application�е�map�Ƚ�
		String ip=request.getRemoteAddr();
		//�����ж�: 
		if(map.containsKey(ip)){   //���ip��map�д���,˵�����ǵ�һ�η���
			int count=map.get(ip);
			map.put(ip, count+1);
		}else{                       //���ip��map�в�����,˵���ǵ�һ�η���
			map.put(ip, 1);
			
		}
		app.setAttribute("map", map); //��map���app��
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		this.app=fConfig.getServletContext();
	}

}
