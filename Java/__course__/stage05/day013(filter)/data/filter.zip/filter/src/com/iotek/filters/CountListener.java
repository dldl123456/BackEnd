package com.iotek.filters;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class CountListener implements ServletContextListener {
    /*
     * �ڷ���������ʱ,����һ��map����,���浽ServletContextȫ�ֶ�����
     */
    public CountListener() {
        // TODO Auto-generated constructor stub
    }

    public void contextInitialized(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    	//����ͻ��˵���ϢIP,���ʴ��� Map--->application
    	Map<String,Integer> map=new LinkedHashMap<String,Integer>();
    	ServletContext application=arg0.getServletContext();
    	application.setAttribute("map", map);
    }


    public void contextDestroyed(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    }
	
}
