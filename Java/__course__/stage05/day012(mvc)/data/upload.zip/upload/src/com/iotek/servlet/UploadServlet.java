package com.iotek.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;


public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//�����ļ�������
		DiskFileItemFactory factory = new DiskFileItemFactory();

		//���ù��������
		//���������ڴ�1M
		factory.setSizeThreshold(1024*10);
		//������ʱĿ¼,�����һ����ʱ�ļ�
		factory.setRepository(new File("c:\\temp"));

		//��ȡ�ϴ����ݵ�servlet
		ServletFileUpload upload = new ServletFileUpload(factory);
        upload.setHeaderEncoding("utf-8");
		// �ϴ��ļ��Ĵ�С
		upload.setSizeMax(1024*100);

		// Parse the request
		try {
			List<FileItem> items = upload.parseRequest(request);
			Iterator<FileItem> iter = items.iterator();
			while (iter.hasNext()) {
			    FileItem item = iter.next();

			    if (item.isFormField()) {  //����
			    	String name = item.getFieldName();
			        String value = item.getString("utf-8");
			        System.out.println("value="+value+" name=="+name);
			        
			    } else {                   //�ļ���
			    	String fieldName = item.getFieldName();
			        String fileName = item.getName();
			        String contentType = item.getContentType();
			        boolean isInMemory = item.isInMemory();
			        long sizeInBytes = item.getSize();
			        System.out.println("fieldName="+fieldName);
			        System.out.println("fileName="+fileName);
			        System.out.println("contentType="+contentType);
			        System.out.println("isInMemory="+isInMemory);
			        System.out.println("sizeInBytes="+sizeInBytes);
			        
			        //�ϴ���·��
			        String path=getServletContext().getRealPath("\\images");
			        
			        //��̬�������Ŀ¼;
			        System.out.println("path=="+path);
			        String fname=path+"\\"+UUID.randomUUID()+".jpg";
			        System.out.println("fname="+fname);
			        FileOutputStream fos=new FileOutputStream(fname);
			        //��ȡ�ϴ�������
			        InputStream is=item.getInputStream();
			        byte content[]=new byte[1024];
			        int length=0;
			        while((length=is.read(content))!=-1){
			        	fos.write(content,0,length);
			        }
			        fos.flush();
			        fos.close();
			        
			       
			    }
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
