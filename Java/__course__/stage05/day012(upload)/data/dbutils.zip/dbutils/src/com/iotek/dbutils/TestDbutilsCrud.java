package com.iotek.dbutils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.iotek.po.User;
import com.iotek.utils.DBUtils;

public class TestDbutilsCrud {
	private static QueryRunner qr=new QueryRunner();  //�����װ��JDBC�����ĺ��Ķ���
	private static Connection conn;
       public static  void addUser(){
    	   conn=DBUtils.getConnection();
    	   String sql="insert into tb_user(username,password,confirmpassword,email,phone) values(?,?,?,?,?)";
    	   try {
			int count=qr.update(conn, sql, "cys","fendou","fendou","yy@11.com","192222");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       public static  void updateUser(){
    	   conn=DBUtils.getConnection();
    	   String sql="update tb_user set username=?,email=? where id=?";
    	   try {
			int count=qr.update(conn, sql, "ucc","uc@yy.com",21);
			System.out.println("count="+count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       
       public static  void deleteUser(){
    	   conn=DBUtils.getConnection();
    	   String sql="delete from tb_user where id=?";
    	   try {
			int count=qr.update(conn, sql, 22);
			System.out.println("count="+count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       
       public static  void getQueryAllUser(){
    	   conn=DBUtils.getConnection();
    	   String sql="select * from tb_user";
    	   try {
			List<User> users=qr.query(conn, sql, new BeanListHandler<User>(User.class));
			System.out.println("users="+users.size());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       
       
       public static  void getUserById(){
    	   conn=DBUtils.getConnection();
    	   String sql="select * from tb_user where id=?";
    	   try {
			User user=qr.query(conn, sql, new BeanHandler<User>(User.class), 21);
			System.out.println("user="+user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       
       public static  void countUser(){
    	   conn=DBUtils.getConnection();
    	   String sql="select count(*) from tb_user";
    	   try {
			Number num=(Number)qr.query(conn, sql, new ScalarHandler());
			System.out.println("num="+num);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       /*��һ��ת����һ��MAP����*/
       public static  void MapUser(){
    	   conn=DBUtils.getConnection();
    	   String sql="select * from tb_user where id=?";
    	   try {
			Map map=qr.query(conn, sql, new MapHandler(),21);
			System.out.println("map="+map);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       
       /*�Ѷ���ת����һ��MAP����-===List<Map>*/
       public static  void MapListUser(){
    	   conn=DBUtils.getConnection();
    	   String sql="select * from tb_user";
    	   try {
			List<Map<String,Object>> mapList=qr.query(conn, sql, new MapListHandler());
			System.out.println("map="+mapList);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
       
}
