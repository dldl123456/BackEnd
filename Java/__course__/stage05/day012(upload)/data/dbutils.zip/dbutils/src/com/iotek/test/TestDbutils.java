package com.iotek.test;

import org.junit.Test;

import com.iotek.dbutils.TestDbutilsCrud;

public class TestDbutils {
	@Test
	public void testAddUser() {
		TestDbutilsCrud.addUser();
	}
	
	@Test
	public void testDeleteUser() {
		TestDbutilsCrud.deleteUser();
	}
	
	@Test
	public void testUpdateUser() {
		TestDbutilsCrud.updateUser();
	}
	@Test
	public void testGetUserById() {
		TestDbutilsCrud.getUserById();
	}
	@Test
	public void testQueryAllUser() {
		TestDbutilsCrud.getQueryAllUser();
	}
	
	@Test
	public void testCountUser() {
		TestDbutilsCrud.countUser();
	}
	@Test
	public void testMapUser() {
		TestDbutilsCrud.MapUser();
	}
	@Test
	public void testMapListUser() {
		TestDbutilsCrud.MapListUser();
	}
}
