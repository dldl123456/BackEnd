package com.iotek.web;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.iotek.user.po.Auth;
import com.iotek.user.service.AuthService;

public class AuthInterceptor extends HandlerInterceptorAdapter {
    @Autowired
	private AuthService authService;
    
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		// TODO Auto-generated method stub
		//��ȡ�û��������ַ
		//�жϵ�ǰ·���Ƿ���Ҫ������֤
		//��ѯ������Ҫ��֤��·������
		String uri=request.getRequestURI();  //��ȡ�����URI��ַ
		System.out.println(uri+"xsdf");
		//path:���ݿ�û�б���permission����Ŀ¼
		String path=request.getSession().getServletContext().getContextPath();
		List<Auth> auths=authService.queryAllAuths();
		Set<String> uriSet=new HashSet<String>();
		for(Auth auth:auths){
			if(auth.getAuthUrl()!=null&&!"".equals(auth.getAuthUrl())){
				uriSet.add(path+auth.getAuthUrl());
			}
		}
		if( uriSet.contains(uri)){
			//Ȩ����֤
			//�жϵ�ǰ�û��Ƿ�ӵ�ж�Ӧ��Ȩ��;
			Set<String> authUriSet=(Set<String>)(request.getSession().getAttribute("authUriSet"));
			System.out.println(authUriSet+"&&&&&");
			if(authUriSet.contains(uri)){
				return true;
			}else{
				response.sendRedirect(path+"/error");
				return false;
			}
		}else{
			return true;
		}
	}
    
}
