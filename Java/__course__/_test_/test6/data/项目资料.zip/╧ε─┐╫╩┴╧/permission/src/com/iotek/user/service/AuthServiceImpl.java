package com.iotek.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iotek.user.dao.AuthDao;
import com.iotek.user.po.Auth;
import com.iotek.user.po.User;
@Service
public class AuthServiceImpl implements AuthService {
	@Autowired
    private  AuthDao authDao;
	public Auth QueryRootAuth() {
		// TODO Auto-generated method stub
		System.out.println("authservice............");
		return authDao.QueryRootAuth();
	}
	public List<Auth> queryChildAuths(Integer pid) {
		// TODO Auto-generated method stub
		return authDao.queryChildAuths(pid);
	}
	public List<Auth> queryAllAuths() {
		// TODO Auto-generated method stub
		return authDao.queryAllAuths();
	}
	public List<Auth> queryAuthByUser(User u) {
		// TODO Auto-generated method stub
		return authDao.queryAuthByUser(u);
	}

}
