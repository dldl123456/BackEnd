package com.iotek.user.service;

import java.util.List;

import com.iotek.user.po.Role;

public interface RoleService {
	 public List<Role> queryRoleAll();
}
