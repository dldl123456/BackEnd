package com.iotek.user.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iotek.user.po.AjaxResult;
import com.iotek.user.po.User;
import com.iotek.user.service.AuthService;
import com.iotek.user.service.UserService;
import com.iotek.user.po.Auth;
@Controller
public class TestController {
	@Autowired
	private UserService userService;
	@Autowired
	private AuthService authService;
	@RequestMapping("/login")
    public String login(){
    	return "login";
    }
	
	@RequestMapping("/error")
    public String error(){
    	return "error";
    }
	@ResponseBody
	@RequestMapping("/json")
	public Object json() {
		Map map = new HashMap();
		map.put("username", "liayin");
		return map;
	}
	@ResponseBody
	@RequestMapping("/queryAllUser")
	public Object queryAllUser() {
	   List<User> users=userService.queryAllUser();
	   return users;
	   
	}
	
	@RequestMapping("/loginout")
	public String loginOut(HttpSession session){
		session.invalidate();
		return "redirect:login";
	}
	@RequestMapping("/main")
	public String main(){
		return "main";
	}
	@ResponseBody
	@RequestMapping("/doAjaxLogin")
	public Object doAjaxLogin(User user,HttpSession session){
		System.out.println("^^^^^^^^^"+user);
		AjaxResult result=new AjaxResult();  //ajax���صĶ���
		User u=userService.login(user);
		if(u!=null){
			session.setAttribute("user", u);
			//��ȡ�û�Ȩ����Ϣ
			Auth root=null;
			List<Auth> auths=authService.queryAuthByUser(u);
			Map<Integer,Auth> authMap=new HashMap<Integer,Auth>();
			
			//��ȡ�û�����Ȩ�޵�uri,������ʹ��74��-83��
			Set<String> uriSet=new HashSet<String>();
			
			for(Auth auth:auths){
				authMap.put(auth.getId(), auth);
				if(auth.getAuthUrl()!=null&&!"".equals(auth.getAuthUrl())){
					uriSet.add(session.getServletContext().getContextPath()+auth.getAuthUrl());
				}
			}
			session.setAttribute("authUriSet", uriSet);
			for(Auth auth:auths){
				Auth child=auth;
				if(child.getAuthParentRoot()==0){
					root=auth;
				}else{
					Auth parent=authMap.get(child.getAuthParentRoot());
					parent.getChildren().add(child);
				}
			}
			session.setAttribute("rootAuth", root);
			result.setSuccess(true);
		}else{
			result.setSuccess(false);
		}
		return result;
	}
	@RequestMapping("/doLogin")
    public String doLogin(User user, Model model){
		System.out.println(user+"****");
		User u=userService.login(user);
		if(u!=null){
			return "main";
		}else{
			// ��½ʧ�ܣ���ת�ص���½ҳ�棬��ʾ������Ϣ
			String errorMsg = "��½�˺Ż����벻��ȷ������������";
			model.addAttribute("errorMsg", errorMsg);
			return "redirect:login";
    	}
    }
}
