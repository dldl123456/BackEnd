package com.iotek.user.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.iotek.user.po.AjaxResult;
import com.iotek.user.po.Role;
import com.iotek.user.po.User;
import com.iotek.user.service.RoleService;
import com.iotek.user.service.UserService;

@Controller
@RequestMapping(value = "user")
public class UserController {

	@Autowired
	private UserService userServcie;
	@Autowired
	private RoleService roleService;

	/**
	 * �û���ҳ
	 * 
	 * @return
	 */
	@RequestMapping("/index")
	public String index(
			@RequestParam(value = "pn", defaultValue = "1") Integer pn,
			Model model) {
		// ��ҳ:
		// ����PageHelper��ҳ���
		// �ڲ�ѯ֮ǰֻ��Ҫ���ã�����ҳ�룬�Լ�ÿҳ�Ĵ�С
		PageHelper.startPage(pn, 5);
		// startPage��������������ѯ����һ����ҳ��ѯ
		List<User> users = null;
		try {
			users = userServcie.queryAllUser();
			System.out.println(users.size());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ʹ��pageInfo��װ��ѯ��Ľ����ֻ��Ҫ��pageInfo����ҳ������ˡ�
		// ��װ����ϸ�ķ�ҳ��Ϣ,���������ǲ�ѯ���������ݣ�����������ʾ��ҳ��
		PageInfo page = new PageInfo(users, 3);

		model.addAttribute("pageInfo", page);
		return "user/index";
	}

	@RequestMapping("/assign")
	public String assign(Integer id, Model model) {

		User user = userServcie.queryUserById(id);
		System.out.println(user + "assign");
		model.addAttribute("user", user);

		List<Role> roles = roleService.queryRoleAll();
		System.out.println("roles" + roles.size());
		// ��ȡ��ϵ��������
		List<Role> assingedRoles = new ArrayList();
		List<Role> unassignRoles = new ArrayList();
		//����userid�����ڵĽ�ɫ�����
		List<Integer> roleids = userServcie.queryRoleidsByUserid(id);
		System.out.println(roleids + "jjjjjjjjjj");
		for (Role role : roles) {
			if (roleids.contains(role.getRoleId())) {

				assingedRoles.add(role);
			} else {
				unassignRoles.add(role);
			}
		}
		System.out.println(assingedRoles.size() + "*aaa*");
		System.out.println(unassignRoles.size() + "*bbb**");
		model.addAttribute("assingedRoles", assingedRoles);
		model.addAttribute("unassignRoles", unassignRoles);

		return "user/assign";
	}

	@ResponseBody
	@RequestMapping("/doAssign")
	public Object doAssign(Integer userid, Integer[] unassignroleids) {
		AjaxResult result = new AjaxResult();

		try {
			// ���ӹ�ϵ������
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("userid", userid);
			map.put("roleids", unassignroleids);
			userServcie.insertUserRoles(map);
			result.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			result.setSuccess(false);
		}

		return result;
	}

	@ResponseBody
	@RequestMapping("/dounAssign")
	public Object dounAssign(Integer userid, Integer[] assignroleids) {
		AjaxResult result = new AjaxResult();

		try {
			// ɾ����ϵ������
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("userid", userid);
			map.put("roleids", assignroleids);
			userServcie.deleteUserRoles(map);
			result.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			result.setSuccess(false);
		}
		return result;
	}

}
