package com.iotek.user.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.iotek.user.po.Auth;
import com.iotek.user.po.User;

public interface AuthDao {

     Auth QueryRootAuth();
	

 	
	 List<Auth> queryChildAuths(Integer pid);



	List<Auth> queryAllAuths();



	List<Auth> queryAuthByUser(User u);
}
