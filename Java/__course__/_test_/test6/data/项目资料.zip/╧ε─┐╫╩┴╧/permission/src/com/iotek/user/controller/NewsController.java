package com.iotek.user.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
@RequestMapping(value="news")
public class NewsController {
	@RequestMapping("/index")
	public String news(){
		return "index";
	}
}
