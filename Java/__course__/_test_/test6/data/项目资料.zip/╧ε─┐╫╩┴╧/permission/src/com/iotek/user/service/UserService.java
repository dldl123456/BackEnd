package com.iotek.user.service;

import java.util.List;
import java.util.Map;

import com.iotek.user.po.Role;
import com.iotek.user.po.User;



public interface UserService {

	List<User> queryAllUser(); 
	public User login(User user);
	User queryUserById(Integer id);
	void insertUserRoles(Map<String, Object> map);
	void deleteUserRoles(Map<String, Object> map);
	List<Integer> queryRoleidsByUserid(Integer id);


}
