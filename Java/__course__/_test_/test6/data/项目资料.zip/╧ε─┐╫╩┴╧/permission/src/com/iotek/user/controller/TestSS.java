package com.iotek.user.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
public class TestSS {
	@RequestMapping("/tt")
	@ResponseBody
	public  Integer ajaxDemo(@RequestBody Map map) {
		System.out.println("ttttt"+map);
	    try {
	        //����ǰ�˴��ݵ�map
	        String str = (String) map.get("account");
	        //��������һϵ�в���,�ж��Ƿ�return 0
	         return 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return 1;
	}
}
