package com.iotek.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iotek.user.dao.RoleDao;
import com.iotek.user.po.Role;


@Service
public class RoleServiceImpl implements RoleService {
	@Autowired
    private RoleDao roleDao;
	public List<Role> queryRoleAll() {
		// TODO Auto-generated method stub
		return roleDao.queryRoleAll();
	}

	
}
