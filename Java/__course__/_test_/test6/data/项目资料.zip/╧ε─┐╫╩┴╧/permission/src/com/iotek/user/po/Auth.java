package com.iotek.user.po;

import java.util.ArrayList;
import java.util.List;

public class Auth {
     private Integer id;
     private String name;
     private String authUrl;
     private Integer authParentRoot;
     private String authIsRoot;
     private String icon;
     private boolean open=true;  //��������Ĭ�ϴ򿪽ڵ�
     private List<Auth> children=new ArrayList<Auth>();  //�Թ���;�ӽڵ㻹��auth����;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthUrl() {
		return authUrl;
	}
	public void setAuthUrl(String authUrl) {
		this.authUrl = authUrl;
	}
	public Integer getAuthParentRoot() {
		return authParentRoot;
	}
	public void setAuthParentRoot(Integer authParentRoot) {
		this.authParentRoot = authParentRoot;
	}
	public String getAuthIsRoot() {
		return authIsRoot;
	}
	public void setAuthIsRoot(String authIsRoot) {
		this.authIsRoot = authIsRoot;
	}
	
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public boolean isOpen() {
		return open;
	}
	public void setOpen(boolean open) {
		this.open = open;
	}
	public List<Auth> getChildren() {
		return children;
	}
	public void setChildren(List<Auth> children) {
		this.children = children;
	}
	@Override
	public String toString() {
		return "Auth [id=" + id + ", name=" + name + ", authUrl=" + authUrl
				+ ", authParentRoot=" + authParentRoot + ", authIsRoot="
				+ authIsRoot + ", icon=" + icon + ", open=" + open
				+ ", children=" + children + "]";
	}
	
	
     
}
