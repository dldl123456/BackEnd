/*
SQLyog Ultimate v11.27 (32 bit)
MySQL - 5.7.11-log : Database - rbac
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`rbac` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `rbac`;

/*Table structure for table `tb_auth` */

DROP TABLE IF EXISTS `tb_auth`;

CREATE TABLE `tb_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `authUrl` varchar(100) DEFAULT NULL,
  `authParentRoot` int(11) DEFAULT NULL,
  `authIsRoot` varchar(2) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `tb_auth` */

insert  into `tb_auth`(`id`,`name`,`authUrl`,`authParentRoot`,`authIsRoot`,`icon`) values (1,'系统菜单',NULL,0,NULL,'glyphicon glyphicon-dashboard'),(2,'控制面版','',1,NULL,'glyphicon glyphicon-dashboard'),(3,'权限管理','/permission/index',1,NULL,'glyphicon glyphicon-dashboard'),(4,'角色维护','/role/index',3,NULL,'glyphicon glyphicon-king'),(5,'用户维护','/user/index',3,NULL,'glyphicon glyphicon-user'),(6,'新闻管理','/news/index',1,NULL,NULL),(7,'新闻维护',NULL,6,NULL,NULL),(8,'栏目维护',NULL,6,NULL,NULL);

/*Table structure for table `tb_role` */

DROP TABLE IF EXISTS `tb_role`;

CREATE TABLE `tb_role` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(30) DEFAULT NULL,
  `rolecontent` varchar(200) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updater` int(11) DEFAULT NULL,
  `updatedate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `tb_role` */

insert  into `tb_role`(`roleid`,`rolename`,`rolecontent`,`creator`,`createdate`,`updater`,`updatedate`) values (1,'项目经理',NULL,NULL,'2018-07-03 15:49:29',NULL,'2018-07-03 15:49:19'),(2,'软件工程师',NULL,NULL,'2018-07-03 15:49:32',NULL,'2018-07-03 15:49:19'),(3,'程序员',NULL,NULL,'2018-07-03 15:49:33',NULL,'2018-07-03 15:49:19'),(4,'组长',NULL,NULL,'2018-07-03 15:49:34',NULL,'2018-07-03 15:49:19'),(5,'测试员',NULL,NULL,'2018-07-03 15:49:35',NULL,'2018-07-03 15:49:19'),(6,'软件架构师',NULL,NULL,'2018-07-03 15:49:36',NULL,'2018-07-03 15:49:19'),(7,'配置管理',NULL,NULL,'2018-07-03 15:49:36',NULL,'2018-07-03 15:49:19'),(8,'系统管理员',NULL,NULL,'2018-07-03 15:49:37',NULL,'2018-07-03 15:49:19');

/*Table structure for table `tb_role_auth` */

DROP TABLE IF EXISTS `tb_role_auth`;

CREATE TABLE `tb_role_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleId` int(11) DEFAULT NULL,
  `authId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `tb_role_auth` */

insert  into `tb_role_auth`(`id`,`roleId`,`authId`) values (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5);

/*Table structure for table `tb_type` */

DROP TABLE IF EXISTS `tb_type`;

CREATE TABLE `tb_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(30) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `tb_type` */

insert  into `tb_type`(`id`,`cname`,`pid`,`desc`) values (1,'小说',0,NULL),(2,'武侠小说',1,NULL),(3,'言情小说',1,NULL),(4,'小李飞刀',2,NULL),(5,'新龙门客栈',2,NULL);

/*Table structure for table `tb_user` */

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(100) DEFAULT NULL,
  `PASSWORD` varchar(100) DEFAULT NULL,
  `USERTRUENAME` varchar(100) DEFAULT NULL,
  `USERSTATE` varchar(2) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATEDATE` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `UPDATER` int(11) DEFAULT NULL,
  `UPDATEDATE` timestamp(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000',
  PRIMARY KEY (`UserId`),
  KEY `USER_ID` (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

/*Data for the table `tb_user` */

insert  into `tb_user`(`UserId`,`USERNAME`,`PASSWORD`,`USERTRUENAME`,`USERSTATE`,`CREATOR`,`CREATEDATE`,`UPDATER`,`UPDATEDATE`) values (1,'admin','admin','liayin','1',1,'2018-06-29 15:16:28.638177',1,'2018-06-29 15:16:18.000000'),(2,'liayin','fendou','nblyp','1',1,'2018-06-29 21:25:34.550247',NULL,'2018-06-22 21:25:29.000000'),(3,'css','css','css','1',1,'2018-07-03 13:44:34.097238',NULL,'2018-06-22 21:25:29.000000'),(4,'liayin1','fendou','liayin1','1',1,'2018-07-03 13:44:35.560321',NULL,'2018-06-22 21:25:29.000000'),(5,'liayin2','fendou','liayin2','1',1,'2018-07-03 13:44:36.537377',NULL,'2018-06-22 21:25:29.000000'),(6,'liayin3','fendou','liayin3','1',1,'2018-07-03 13:44:40.177586',NULL,'2018-06-22 21:25:29.000000'),(7,'liayin4','fendou','liayin4','1',1,'2018-07-03 13:44:41.258647',NULL,'2018-06-22 21:25:29.000000'),(8,'liayin5','liayin5','liayin5','1',1,'2018-07-03 13:44:42.322708',NULL,'2018-06-22 21:25:29.000000'),(9,'liayin6','liayin6','liayin6','1',1,'2018-07-03 13:44:43.306765',NULL,'2018-06-22 21:25:29.000000'),(10,'liayin7','liayin7','liayin7','1',1,'2018-07-03 13:44:44.999861',NULL,'2018-06-22 21:25:29.000000'),(11,'liayin8','liayin8','liayin8','1',1,'2018-07-03 13:44:53.784364',NULL,'2018-06-22 21:25:29.000000'),(12,'liayin9','liayin9','liayin9','1',1,'2018-07-03 13:44:54.873426',NULL,'2018-06-22 21:25:29.000000'),(13,'liayin10','liayin10','liayin10','1',1,'2018-07-03 13:44:55.731475',NULL,'2018-06-22 21:25:29.000000'),(14,'liayin11','liayin11','liayin11','1',1,'2018-07-03 13:44:56.576523',NULL,'2018-06-22 21:25:29.000000'),(15,'liayin12','liayin12','liayin12','1',1,'2018-07-03 13:44:57.369569',NULL,'2018-06-22 21:25:29.000000'),(16,'liayin13','liayin13','liayin13','1',1,'2018-07-03 13:44:58.658643',NULL,'2018-06-22 21:25:29.000000'),(17,'liayin14','liayin14','liayin14','1',1,'2018-07-03 13:44:59.961717',NULL,'2018-06-22 21:25:29.000000'),(18,'liayin15','liayin15','liayin15','1',1,'2018-07-03 13:45:00.888770',NULL,'2018-06-22 21:25:29.000000'),(19,'liayin16','liayin16','liayin16','1',1,'2018-07-03 13:45:02.733876',NULL,'2018-06-22 21:25:29.000000'),(20,'liayin17','liayin17','liayin17','1',1,'2018-07-03 13:45:05.049008',NULL,'2018-06-22 21:25:29.000000'),(21,'liayin18','liayin18','liayin18','1',1,'2018-07-03 13:45:06.401085',NULL,'2018-06-22 21:25:29.000000'),(22,'liayin19','liayin19','liayin19','1',1,'2018-07-03 13:45:07.274135',NULL,'2018-06-22 21:25:29.000000'),(23,'liayin20','liayin20','liayin20','1',1,'2018-07-03 13:45:08.966232',NULL,'2018-06-22 21:25:29.000000'),(24,'liayin21','liayin21','liayin21','1',1,'2018-07-03 13:45:10.273307',NULL,'2018-06-22 21:25:29.000000'),(25,'liayin22','liayin22','liayin22','1',1,'2018-07-03 13:45:11.186359',NULL,'2018-06-22 21:25:29.000000'),(26,'liayin23','liayin23','liayin23','1',1,'2018-07-03 13:45:14.062524',NULL,'2018-06-22 21:25:29.000000'),(27,'liayin24','liayin24','liayin24','1',1,'2018-07-03 13:45:14.898571',NULL,'2018-06-22 21:25:29.000000'),(28,'liayin25','liayin25','liayin25','1',1,'2018-07-03 13:45:15.664615',NULL,'2018-06-22 21:25:29.000000'),(29,'liayin26','liayin26','liayin26','1',1,'2018-07-03 13:45:16.524664',NULL,'2018-06-22 21:25:29.000000'),(30,'liayin27','liayin27','liayin27','1',1,'2018-07-03 13:45:17.968747',NULL,'2018-06-22 21:25:29.000000'),(31,'liayin28','liayin28','liayin28','1',1,'2018-07-03 13:45:18.727790',NULL,'2018-06-22 21:25:29.000000'),(32,'liayin29','liayin29','liayin29','1',1,'2018-07-03 13:45:19.487834',NULL,'2018-06-22 21:25:29.000000'),(33,'liayin30','liayin30','liayin30','1',1,'2018-07-03 13:45:20.456889',NULL,'2018-06-22 21:25:29.000000'),(34,'liayin31','liayin31','liayin31','1',1,'2018-07-03 13:45:21.810967',NULL,'2018-06-22 21:25:29.000000'),(35,'liayin32','liayin32','liayin32','1',1,'2018-07-03 13:45:22.792023',NULL,'2018-06-22 21:25:29.000000'),(36,'liayin33','liayin33','liayin33','1',1,'2018-07-03 13:45:27.056267',NULL,'2018-06-22 21:25:29.000000');

/*Table structure for table `tb_user_role` */

DROP TABLE IF EXISTS `tb_user_role`;

CREATE TABLE `tb_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `roleid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

/*Data for the table `tb_user_role` */

insert  into `tb_user_role`(`id`,`userid`,`roleid`) values (43,1,1),(44,1,2),(45,11,1),(46,11,2),(49,11,3),(50,11,4),(51,11,5),(52,11,7),(54,1,4),(55,1,5);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
