package com.iotek.user.service;

import java.util.List;

import com.iotek.user.po.Auth;
import com.iotek.user.po.User;

public interface AuthService {
	Auth QueryRootAuth();

	List<Auth> queryChildAuths(Integer id);

	List<Auth> queryAllAuths();

	List<Auth> queryAuthByUser(User u);
}
