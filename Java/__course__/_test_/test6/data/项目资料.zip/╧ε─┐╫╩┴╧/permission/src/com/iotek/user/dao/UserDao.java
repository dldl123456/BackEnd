package com.iotek.user.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.iotek.user.po.Role;
import com.iotek.user.po.User;
@Repository
public interface UserDao {
	
     public List<User> queryAllUser();
     public User login(User user);
	 public User queryUserById(int id);
	 public void insertUserRoles(Map<String, Object> map);
	 public void deleteUserRoles(Map<String, Object> map);
	 @Select("select roleid from tb_user_role where userid=#{userid}")
	 public List<Integer> queryRoleidsByUserid(Integer id);
}
