package com.iotek.user.dao;

import java.util.List;

import com.iotek.user.po.Role;

public interface RoleDao {
    public List<Role> queryRoleAll();
}
