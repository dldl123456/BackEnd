package com.iotek.user.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iotek.user.po.Auth;
import com.iotek.user.service.AuthService;
import com.iotek.user.service.UserService;

@Controller
@RequestMapping("/permission")
public class PremissionController {
	@Autowired
	private AuthService authService;
	
	@RequestMapping("/index")
    public String index(){
    	return "permission/index";
    }
    @ResponseBody
	@RequestMapping("/loadData")
    public Object loadData(){
    	
    	System.out.println("xxxxxloaddata...");
    	/*
    	List<Auth> auths=new ArrayList<Auth>();
    	Auth root=new Auth();
    	root.setName("�����ڵ�");
    	Auth child=new Auth();
    	child.setName("�ӽڵ�");
    	
    	root.getChildren().add(child);
    	auths.add(root);
    	//return "permission/index";
    	 */
    	/*
    	
    	List<Auth> auths=new ArrayList<Auth>();
    	Auth root=authService.QueryRootAuth();
    	System.out.println(root+"���ڵ�...");
    	List<Auth> childAuths=authService.queryChildAuths(root.getId());
    	root.setChildren(childAuths);
    	auths.add(root);
    	*/
    	//���ø����0
    	//�ݹ� ztree�ؼ� ����һ
    	/*
    	Auth parent =new Auth();
    	
    	parent.setId(0);
    	
    	queryChildAuths(parent);
    	System.out.println(parent.getChildren().size()+"&&&");
    	return parent.getChildren();
    	*/
    	//��ѯ���е�Ȩ������ ������ ztree,˫ѭ��
    	
    	List<Auth> authsList=new ArrayList<Auth>();
    	List<Auth> auths=authService.queryAllAuths();
    	System.out.println(auths+"**********");
    	/*
    	for(Auth auth:auths){
    		//ÿһ���ڵ㶼���������ӽڵ�
    		Auth child=auth;
    		//Ȼ��������ĸ��ڵ�,0��û�и��ڵ��
    		if(auth.getAuthParentRoot()==0){
    			authsList.add(auth);
    		}else{
    			for(Auth innerAuth : auths){
    			  if(child.getAuthParentRoot().equals(innerAuth.getId())){
    				  //���ڵ�
    				  Auth parent=innerAuth;
    				  //��ϸ��ӽڵ�Ĺ�ϵ
    				  parent.getChildren().add(child);
    				  break;
    			  }	
    			}
    		}
    	
    		
    	}
    	System.out.println(authsList+"*****");
    	return authsList;
    	*/
       
    	Map<Integer,Auth> authMap=new HashMap<Integer,Auth>();
    	for(Auth auth:auths){
    		authMap.put(auth.getId(), auth);
    	}
    	for(Auth auth:auths){
    		Auth child=auth;
    		if(child.getAuthParentRoot()==0){
    			authsList.add(auth);
    		}else{
    			Auth parent =authMap.get(child.getAuthParentRoot());
    			parent.getChildren().add(child);
    		}
    	}
    	System.out.println(authsList+"*****");
    	return authsList;
    	
    }
    //�ݹ��ѯȨ����Ϣ
    /*
    public void queryChildAuths(Auth parent){
    	System.out.println(parent.getAuthParentRoot()+"ttt");
    	List<Auth> childAuths=authService.queryChildAuths(parent.getId());
    	
    	for(Auth auth:childAuths){
    		System.out.println("auth"+auth.getAuthParentRoot());
    		queryChildAuths(auth);
    	}
    	parent.setChildren(childAuths);
    }
    */
    
	
}
