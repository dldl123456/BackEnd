package com.iotek.user.po;
/*
 * ajax���ض���
 */
public class AjaxResult {
    private boolean success;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
    
}
